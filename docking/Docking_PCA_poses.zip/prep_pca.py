from rdkit import Chem
from rdkit.Chem import AllChem
from meeko import MoleculePreparation, PDBQTWriterLegacy
SMI = "Nc1nc2ncc(C(=O)[O-])nc2c(=O)[nH]1"     # PCA a pH 7.4 (carboxilato, carga -1)
mol = Chem.AddHs(Chem.MolFromSmiles(SMI))
AllChem.EmbedMolecule(mol, randomSeed=42); AllChem.MMFFOptimizeMolecule(mol, maxIters=2000)
mol.SetProp("_Name", "PCA_pH74"); Chem.MolToMolFile(mol, "PCA_dock_input.sdf")
st = MoleculePreparation().prepare(mol); pq, ok, err = PDBQTWriterLegacy.write_string(st[0])
open("PCA_dock_input.pdbqt", "w").write(pq)
print("carga", Chem.GetFormalCharge(mol), "pesados", mol.GetNumHeavyAtoms(), "torsiones", pq.count("BRANCH")//2, ok)

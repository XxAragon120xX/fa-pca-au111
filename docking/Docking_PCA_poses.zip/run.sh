V=/home/claude/dock/bin/vina
for B in 18 25; do
 $V --receptor proteina.pdbqt --ligand PCA_dock_input.pdbqt --center_x 6.43 --center_y 21.76 --center_z 2.22 \
   --size_x $B --size_y $B --size_z $B --exhaustiveness 32 --num_modes 20 --energy_range 4 --seed 42 --cpu 2 \
   --out PCA_dock_caja$B.pdbqt > log_caja$B.txt 2>&1
done
echo done

import re, sys, numpy as np
from rdkit import Chem
from meeko import PDBQTMolecule, RDKitMolCreate
from Bio.PDB import PDBParser, NeighborSearch
core = Chem.MolFromSmarts("[#7]~[#6]1~[#7]~[#6]2~[#7]~[#6]~[#6]~[#7]~[#6]2~[#6](~[#8])~[#7]~1")
def skel(m):
    m = Chem.RemoveHs(m, sanitize=False); rw = Chem.RWMol(m)
    for b in rw.GetBonds(): b.SetBondType(Chem.BondType.SINGLE); b.SetIsAromatic(False)
    for a in rw.GetAtoms(): a.SetFormalCharge(0); a.SetIsAromatic(False); a.SetNumExplicitHs(0); a.SetNoImplicit(True)
    return rw.GetMol(), m
def analyze(pdbqt, prot_pdb, ref_sdf_or_pdb, quiet=False):
    if ref_sdf_or_pdb.endswith('.sdf'): ref = Chem.SDMolSupplier(ref_sdf_or_pdb, removeHs=False)[0]
    else: ref = Chem.MolFromPDBFile(ref_sdf_or_pdb, removeHs=True, proximityBonding=True)
    rS, rH = skel(ref); rx = rH.GetConformer().GetPositions(); cr = list(rS.GetSubstructMatch(core))
    pm = PDBQTMolecule.from_file(pdbqt, skip_typing=True); pr = RDKitMolCreate.from_pdbqt_mol(pm)[0]; pS, pH = skel(pr)
    cps = pS.GetSubstructMatches(core, uniquify=False)
    sc = [float(x) for x in re.findall(r"REMARK VINA RESULT:\s+(-?\d+\.\d+)", open(pdbqt).read())]
    prot = PDBParser(QUIET=True).get_structure('p', prot_pdb); ns = NeighborSearch(list(prot.get_atoms()))
    def cont(xyz, d=4.0):
        s = set()
        for p in xyz:
            for a in ns.search(p, d): r = a.get_parent(); s.add((r.get_resname(), r.id[1]))
        return s
    cref = cont(rx[cr]); out = []
    for i in range(pH.GetNumConformers()):
        px = pH.GetConformer(i).GetPositions()
        rmsd = min(np.sqrt(np.mean(np.sum((rx[cr] - px[list(m)])**2, 1))) for m in cps)
        cp = cont(px[list(cps[0])]); out.append((i+1, sc[i], rmsd, len(cp & cref)/len(cref)))
    return out, cref
if __name__ == '__main__':
    for B in (18, 25):
        res, cref = analyze(f'PCA_dock_caja{B}.pdbqt', 'proteina.pdb', 'FA_cristal_ref.sdf')
        print(f'== caja {B} Å   (residuos de referencia: {", ".join(f"{n}{k}" for n,k in sorted(cref, key=lambda x:x[1]))})')
        print(' pose  score  RMSD_pterina  contactos')
        for r in res: print(' %3d  %6.2f  %8.2f  %8.0f%%' % (r[0], r[1], r[2], 100*r[3]))

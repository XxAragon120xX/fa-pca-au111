import numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.gridspec import GridSpec
from PIL import Image
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif'],
                     'mathtext.fontset':'stix','font.size':9,'pdf.fonttype':42})
def load(f):
    a=np.array(Image.open(f).convert('RGB'))[150:1150]; m=(a>238).all(-1); a[m]=255; return a
c=np.array(Image.open('panel_c.png').convert('RGB'))
fig=plt.figure(figsize=(7.2,5.1))
gs=GridSpec(2,4,height_ratios=[0.98,1.22],width_ratios=[1,1,1,1],
            hspace=0.17,wspace=0.03,figure=fig)
for k,(t,lab) in enumerate([('FA','(a) FA/Au(111), V-Z-Pt'),('PCA','(b) PCA/Au(111), F-B')]):
    a=fig.add_subplot(gs[0,2*k:2*k+2]); a.imshow(load(f'{t}_drho.png'))
    a.set_xticks([]); a.set_yticks([])
    for s in a.spines.values(): s.set_color('#c9c8c2'); s.set_linewidth(0.6)
    a.set_title(lab,loc='left',fontsize=10)
ac=fig.add_subplot(gs[1,1:3]); ac.imshow(c); ac.axis('off')
ac.set_title('(c) planar-averaged '+r'$\Delta\rho$',loc='left',fontsize=10)
fig.legend(handles=[Patch(color='#d91f1f',label=r'$\Delta\rho > 0$ (accumulation)'),
                    Patch(color='#2161eb',label=r'$\Delta\rho < 0$ (depletion)')],
           loc='lower center',ncol=2,frameon=False,fontsize=8.5,bbox_to_anchor=(0.5,-0.004))
fig.text(0.99,0.012,r'isosurfaces $\pm$0.0015 e bohr$^{-3}$',ha='right',fontsize=8,color='#52514e')
fig.subplots_adjust(left=0.008,right=0.992,top=0.955,bottom=0.055)
for e in ('png','pdf'): fig.savefig(f'Figure3_drho.{e}',dpi=600)
print('ok')

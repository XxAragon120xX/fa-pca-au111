import numpy as np
B=0.529177210903
def planar(cube):
    C=open(cube).read().split('\n')
    nat=abs(int(C[2].split()[0])); org=np.array(C[2].split()[1:4],float)
    n=[int(C[3+i].split()[0]) for i in range(3)]
    v=np.array([C[3+i].split()[1:4] for i in range(3)],float)
    at=[C[6+i].split() for i in range(nat)]
    Z=np.array([int(float(a[0])) for a in at]); X=np.array([[float(x) for x in a[2:5]] for a in at])
    d=np.array(' '.join(C[6+nat:]).split(),float).reshape(n)       # e/Bohr^3
    # area lateral y paso en z (Bohr)
    a1,a2=n[0]*v[0], n[1]*v[1]
    A=abs(a1[0]*a2[1]-a1[1]*a2[0])                                  # Bohr^2
    dz=v[2,2]
    z=(org[2]+np.arange(n[2])*dz)*B                                  # A
    # promedio planar (e/Bohr^3) y densidad lineal (e/Bohr)
    avg=d.mean(axis=(0,1))
    lin=avg*A                                                        # e/Bohr
    cum=np.cumsum(lin)*dz                                            # e acumulados
    au=X[Z==79][:,2]*B
    ztop=au[au>au.max()-0.6].mean()
    mol=X[Z!=79][:,2]*B
    return z-ztop, avg, lin, cum, mol.min()-ztop
for tag,f in (('FA  (V-Z-Pt)','/mnt/user-data/uploads/Au/Figura_union/drho_FA_recortado.cube'),
              ('PCA (F-B)   ','/mnt/user-data/uploads/Au/Figura_union/drho_FB_recortado.cube')):
    z,avg,lin,cum,hmin=planar(f)
    m=(z>-0.2)&(z<6)
    zi,li=z[m],lin[m]
    ip=zi[np.argmax(li)]; im=zi[np.argmin(li)]
    # carga desplazada: integral de la parte positiva entre superficie y molecula
    pos=np.trapezoid(np.clip(li,0,None),zi/B)
    print(f'{tag}  atomo mas bajo del ligando a {hmin:.2f} A')
    print(f'   acumulacion maxima en z = {ip:+.2f} A | deplexion maxima en z = {im:+.2f} A')
    print(f'   carga desplazada (integral de la parte positiva) = {pos:.3f} e')
    far=z[(z>2)&(np.abs(lin)>0.002)]
    print(f'   perturbacion detectable hasta z = {far.max() if len(far) else float("nan"):.1f} A\n')

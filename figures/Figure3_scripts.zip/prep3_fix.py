import numpy as np
from scipy.ndimage import map_coordinates
B = 0.529177210903
SYM = {79: 'Au', 6: 'C', 7: 'N', 8: 'O', 1: 'H'}
def wpdb(fn, els, X, res):
    with open(fn, 'w') as f:
        for k, (e, r) in enumerate(zip(els, X), 1):
            f.write('HETATM%5d %-4s %3s A   1    %8.3f%8.3f%8.3f  1.00  0.00          %2s\n' % (k, e, res, *r, e))
        f.write('END\n')
def build(tag, cube):
    C = open(cube).read().split('\n')
    nat = abs(int(C[2].split()[0])); org = np.array(C[2].split()[1:4], float)
    n = [int(C[3+i].split()[0]) for i in range(3)]; v = np.array([C[3+i].split()[1:4] for i in range(3)], float)
    at = [C[6+i].split() for i in range(nat)]
    Z = np.array([int(float(a[0])) for a in at]); X = np.array([[float(x) for x in a[2:5]] for a in at]) * B
    d = np.array(' '.join(C[6+nat:]).split(), float).reshape(n)
    A1, A2 = n[0]*v[0]*B, n[1]*v[1]*B
    M2 = np.array([[A1[0], A2[0]], [A1[1], A2[1]]]); Mi2 = np.linalg.inv(M2)
    au = X[Z == 79]; mol = X[Z != 79].copy(); me = [SYM[z] for z in Z[Z != 79]]
    # desenvolver la molécula (imagen mínima respecto al átomo anterior conectado)
    for k in range(1, len(mol)):
        ref = mol[:k]; best = None
        for i in (-1, 0, 1):
            for j in (-1, 0, 1):
                p = mol[k] + i*A1 + j*A2; dd = np.min(np.linalg.norm(ref - p, axis=1))
                if best is None or dd < best[0]: best = (dd, p)
        mol[k] = best[1]
    zt = au[:, 2][au[:, 2] > au[:, 2].max() - 0.6].mean()
    c = mol.mean(0); o = np.array([c[0], c[1], zt])
    _, _, vt = np.linalg.svd((mol - c)[:, :2]); ex = np.r_[vt[0], 0.]; ex /= np.linalg.norm(ex)
    R = np.vstack([ex, [0, 0, 1.], np.cross(ex, [0, 0, 1.])])
    tv = lambda P: (P - o) @ R.T
    img = np.vstack([au + i*A1 + j*A2 for i in range(-3, 4) for j in range(-3, 4)])
    Av = tv(img); mv = tv(mol)
    keep = (np.abs(Av[:, 0]) < 12) & (Av[:, 2] > -7) & (Av[:, 2] < 9)
    wpdb(f'{tag}_mol.pdb', me, mv, tag[:3]); wpdb(f'{tag}_au.pdb', ['Au']*keep.sum(), Av[keep], 'AU')
    h = 0.12
    lo = np.array([mv[:, 0].min()-4, -2.5, mv[:, 2].min()-4]); hi = np.array([mv[:, 0].max()+4, mv[:, 1].max()+3, mv[:, 2].max()+4])
    zc_max = (org[2] + (n[2]-1)*v[2, 2]) * B - zt
    hi[1] = min(hi[1], zc_max - 0.1)
    g = [np.arange(lo[i], hi[i], h) for i in range(3)]
    G = np.stack(np.meshgrid(*g, indexing='ij'), -1); Wd = G @ R + o
    rel = Wd[..., :2] - org[:2]*B; f = rel @ Mi2.T
    ii = f[..., 0]*n[0]; jj = f[..., 1]*n[1]; kk = (Wd[..., 2]/B - org[2]) / v[2, 2]
    vals = map_coordinates(d, [ii.ravel(), jj.ravel(), kk.ravel()], order=1, mode='grid-wrap').reshape(G.shape[:3])
    # --- recorte: conservar Drho asignable a la molecula dibujada ---
    # Cada punto se asigna a la copia (dibujada o imagen periodica) mas cercana;
    # solo se conserva si gana la dibujada y esta a menos de RCUT.
    RCUT = 5.0
    from scipy.spatial import cKDTree
    P = G.reshape(-1, 3)
    d0, _ = cKDTree(mv).query(P, k=1)
    dimg = np.full(len(P), np.inf)
    A1v, A2v = tv(A1 + o), tv(A2 + o)      # vectores de red en el marco de vista
    for i in (-1, 0, 1):
        for j in (-1, 0, 1):
            if i == 0 and j == 0: continue
            dd, _ = cKDTree(mv + i*A1v + j*A2v).query(P, k=1)
            dimg = np.minimum(dimg, dd)
    inside = ((d0 <= RCUT) & (d0 < dimg)).reshape(G.shape[:3])
    vals = np.where(inside, vals, 0.0)
    print('   %s: anulado %.1f %% (imagenes periodicas y vacio lejano)' % (tag, 100*(~inside).sum()/inside.size))
    with open(f'{tag}_drho.cube', 'w') as fo:
        fo.write('drho\nview\n%5d %12.6f %12.6f %12.6f\n' % (1, *(lo/B)))
        for k, m in enumerate(vals.shape):
            vv = [0, 0, 0]; vv[k] = h/B; fo.write('%5d %12.6f %12.6f %12.6f\n' % (m, *vv))
        fo.write('%5d %12.6f %12.6f %12.6f %12.6f\n' % (1, 0, 0, 0, 0))
        for row in vals.reshape(-1, vals.shape[2]):
            for j in range(0, len(row), 6): fo.write(' '.join('%13.5E' % x for x in row[j:j+6]) + '\n')
    print(tag, 'mol', len(mol), 'h min/max %.2f %.2f' % (mv[:, 1].min(), mv[:, 1].max()), 'Δρ', vals.min().round(4), vals.max().round(4))
build('FA', '/mnt/user-data/uploads/Au/Figura_union/drho_FA_recortado.cube')
build('PCA', '/mnt/user-data/uploads/Au/Figura_union/drho_FB_recortado.cube')

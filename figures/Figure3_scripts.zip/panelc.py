import sys; sys.path.insert(0,'/tmp/claude-0/-home-claude/55059600-48b1-535c-9792-8006a72a8889/scratchpad/SI')
import numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
B=0.529177210903
def planar(cube):
    C=open(cube).read().split('\n')
    nat=abs(int(C[2].split()[0])); org=np.array(C[2].split()[1:4],float)
    n=[int(C[3+i].split()[0]) for i in range(3)]
    v=np.array([C[3+i].split()[1:4] for i in range(3)],float)
    at=[C[6+i].split() for i in range(nat)]
    Z=np.array([int(float(a[0])) for a in at]); X=np.array([[float(x) for x in a[2:5]] for a in at])
    d=np.array(' '.join(C[6+nat:]).split(),float).reshape(n)
    a1,a2=n[0]*v[0],n[1]*v[1]; A=abs(a1[0]*a2[1]-a1[1]*a2[0])
    z=(org[2]+np.arange(n[2])*v[2,2])*B
    lin=d.mean(axis=(0,1))*A/B          # e/A
    au=X[Z==79][:,2]*B; ztop=au[au>au.max()-0.6].mean()
    mol=X[Z!=79][:,2]*B
    return z-ztop, lin, mol.min()-ztop
zF,lF,hF=planar('/mnt/user-data/uploads/Au/Figura_union/drho_FA_recortado.cube')
zP,lP,hP=planar('/mnt/user-data/uploads/Au/Figura_union/drho_FB_recortado.cube')
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif'],
                     'mathtext.fontset':'stix','font.size':9,'pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(3.3,2.95))
ax.axhline(0,color='0.6',lw=0.7)
ax.plot(zF,lF,color='#1f3f8f',lw=1.6,label='FA (V-Z-Pt)')
ax.plot(zP,lP,color='#c0392b',lw=1.6,ls='--',label='PCA (F-B)')
ax.axvline(0,color='#b8860b',lw=1.0,ls=':')
ax.text(0.06,0.96,'top Au layer',transform=ax.transAxes,fontsize=7.5,color='#8a6d1f',rotation=90,va='top')
ax.set_xlim(-3,8); ax.set_xlabel(r'$z$ relative to the topmost Au layer ($\mathrm{\AA}$)')
ax.set_ylabel(r'planar-averaged $\Delta\rho$  (e $\mathrm{\AA}^{-1}$)')
ax.legend(frameon=False,fontsize=8.5,loc='lower right')
ax.tick_params(direction='in',top=True,right=True)
fig.tight_layout(pad=0.4); fig.savefig('panel_c.png',dpi=600); print('ok  FA hmin %.2f  PCA hmin %.2f'%(hF,hP))

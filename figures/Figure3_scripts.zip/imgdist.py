import numpy as np
from scipy.spatial import cKDTree
B=0.529177210903
for tag,cube in (('FA  (V-Z-Pt)','/mnt/user-data/uploads/Au/Figura_union/drho_FA_recortado.cube'),
                 ('PCA (F-B)   ','/mnt/user-data/uploads/Au/Figura_union/drho_FB_recortado.cube')):
    C=open(cube).read().split('\n')
    nat=abs(int(C[2].split()[0])); org=np.array(C[2].split()[1:4],float)
    n=[int(C[3+i].split()[0]) for i in range(3)]
    v=np.array([C[3+i].split()[1:4] for i in range(3)],float)
    at=[C[6+i].split() for i in range(nat)]
    Z=np.array([int(float(a[0])) for a in at]); X=np.array([[float(x) for x in a[2:5]] for a in at])*B
    A1,A2=n[0]*v[0]*B, n[1]*v[1]*B
    mol=X[Z!=79].copy()
    for k in range(1,len(mol)):
        ref=mol[:k]; best=None
        for i in (-1,0,1):
            for j in (-1,0,1):
                p=mol[k]+i*A1+j*A2; dd=np.min(np.linalg.norm(ref-p,axis=1))
                if best is None or dd<best[0]: best=(dd,p)
        mol[k]=best[1]
    t=cKDTree(mol); best=(1e9,None)
    for i in range(-2,3):
        for j in range(-2,3):
            if i==0 and j==0: continue
            d,_=t.query(mol+i*A1+j*A2,k=1)
            if d.min()<best[0]: best=(d.min(),(i,j))
    ext=np.linalg.norm(mol[:,None,:2]-mol[None,:,:2],axis=-1).max()
    print(f'{tag}: extension lateral maxima {ext:5.1f} A | distancia minima a la imagen periodica mas cercana '
          f'{best[0]:5.2f} A  (imagen {best[1]})')

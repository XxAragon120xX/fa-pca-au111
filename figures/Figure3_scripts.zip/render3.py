from pymol import cmd
def scene(tag):
    cmd.reinitialize(); cmd.bg_color('white')
    for k, v in [('ray_trace_mode', 1), ('ray_trace_gain', 0.05), ('ray_trace_color', 'grey25'), ('antialias', 2), ('ray_shadows', 1),
                 ('ambient', 0.45), ('specular', 0.3), ('spec_power', 120), ('orthoscopic', 1), ('depth_cue', 0),
                 ('stick_radius', 0.16), ('stick_ball', 1), ('stick_ball_ratio', 1.8), ('transparency_mode', 3), ('two_sided_lighting', 1)]:
        cmd.set(k, v)
    cmd.set_color('aucol', [0.93, 0.74, 0.25]); cmd.set_color('ccol', [0.55, 0.55, 0.55]); cmd.set_color('ncol', [0.19, 0.35, 0.85])
    cmd.set_color('ocol', [0.88, 0.16, 0.16]); cmd.set_color('acc', [0.85, 0.12, 0.12]); cmd.set_color('dep', [0.13, 0.38, 0.92])
    cmd.load(f'{tag}_au.pdb', 'au'); cmd.load(f'{tag}_mol.pdb', 'mol'); cmd.load(f'{tag}_drho.cube', 'map')
    cmd.show_as('spheres', 'au'); cmd.alter('au', 'vdw=1.44'); cmd.set('sphere_scale', 0.55, 'au'); cmd.color('aucol', 'au')
    cmd.show_as('sticks', 'mol'); cmd.show('spheres', 'mol'); cmd.set('sphere_scale', 0.25, 'mol'); cmd.set('sphere_scale', 0.17, 'mol and elem H')
    cmd.color('ccol', 'mol and elem C'); cmd.color('ncol', 'mol and elem N'); cmd.color('ocol', 'mol and elem O'); cmd.color('white', 'mol and elem H')
    cmd.isosurface('ip', 'map', 0.0015); cmd.isosurface('im', 'map', -0.0015)
    cmd.color('acc', 'ip'); cmd.color('dep', 'im'); cmd.set('transparency', 0.25, 'ip'); cmd.set('transparency', 0.25, 'im')
    cmd.hide('everything', 'map') if False else None
    cmd.rebuild(); cmd.reset(); cmd.turn('x', 14)
    for k, (x, y) in enumerate([(-9.8, -1.5), (9.8, -1.5), (-9.8, 13.0), (9.8, 13.0)]): cmd.pseudoatom(f'bx{k}', pos=[x, y, 0.0])
    cmd.zoom('bx*', 0.0); cmd.delete('bx*')
    cmd.png(f'{tag}_drho.png', width=1600, height=1200, dpi=300, ray=1); print(tag, 'ok')
for t in ('FA', 'PCA'): scene(t)

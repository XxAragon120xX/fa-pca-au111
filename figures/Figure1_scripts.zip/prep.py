import re, numpy as np
U='/mnt/user-data/uploads/Au/'
def rd(f):
    L=open(f).read().splitlines(); pos=[]; cell=None
    for i,l in enumerate(L):
        s=l.strip().upper()
        if s.startswith('CELL_PARAMETERS'): cell=np.array([[float(x) for x in L[i+k].split()[:3]] for k in (1,2,3)])
        if s.startswith('ATOMIC_POSITIONS'):
            j=i+1
            while j<len(L) and re.match(r'^\s*[A-Za-z]{1,2}\s+-?\d',L[j]): t=L[j].split(); pos.append((t[0],*map(float,t[1:4]))); j+=1
    el=np.array([p[0] for p in pos]); X=np.array([p[1:] for p in pos]); return el,X,cell
def wpdb(fn,els,X,res):
    with open(fn,'w') as f:
        for k,(e,r) in enumerate(zip(els,X),1):
            f.write('HETATM%5d %-4s %3s A   1    %8.3f%8.3f%8.3f  1.00  0.00          %2s\n'%(k,e,res,*r,e))
        f.write('END\n')
for tag,fn in [('FA',U+'Docking/V-Z-Pt.in'),('PCA',U+'Figura_union/PCA_FB_A.in')]:
    el,X,cell=rd(fn); au=X[el=='Au']; m=X[el!='Au']; me=el[el!='Au']
    zt=au[:,2][au[:,2]>au[:,2].max()-0.6].mean(); c=m.mean(0); o=np.array([c[0],c[1],zt])
    img=np.vstack([au+i*cell[0]+j*cell[1] for i in range(-3,4) for j in range(-3,4)])
    _,_,vt=np.linalg.svd((m-c)[:,:2]); ex=np.r_[vt[0],0.]; ex/=np.linalg.norm(ex); ez=np.array([0,0,1.]); ey=np.cross(ez,ex)
    # vista lateral: x=eje largo, y=normal, z=hacia el observador
    Rs=np.vstack([ex,ez,np.cross(ex,ez)]); ms=(m-o)@Rs.T; as_=(img-o)@Rs.T
    keep=(np.abs(as_[:,0])<20)&(as_[:,2]>-9)&(as_[:,2]<7)
    wpdb(f'{tag}_side_mol.pdb',me,ms,tag[:3]); wpdb(f'{tag}_side_au.pdb',['Au']*keep.sum(),as_[keep],'AU')
    # vista superior: x=eje largo, y=perpendicular en el plano, z=normal (hacia el observador)
    Rt=np.vstack([ex,ey,ez]); mt=(m-o)@Rt.T; at=(img-o)@Rt.T
    keep=(np.abs(at[:,0])<20)&(np.abs(at[:,1])<14)&(at[:,2]>-3.0)
    wpdb(f'{tag}_top_mol.pdb',me,mt,tag[:3]); wpdb(f'{tag}_top_au.pdb',['Au']*keep.sum(),at[keep],'AU')
    print(tag, len(m), 'altura máx', round(ms[:,1].max(),2), 'mín', round(ms[:,1].min(),2))

from pymol import cmd
def style():
    cmd.reinitialize(); cmd.bg_color('white')
    for k,v in [('ray_trace_mode',1),('ray_trace_gain',0.05),('ray_trace_color','grey25'),('antialias',2),('ray_shadows',1),
                ('ambient',0.45),('specular',0.3),('spec_power',120),('orthoscopic',1),('depth_cue',0),
                ('stick_radius',0.16),('stick_ball',1),('stick_ball_ratio',1.8)]: cmd.set(k,v)
    cmd.set_color('aucol',[0.93,0.74,0.25]); cmd.set_color('ccol',[0.55,0.55,0.55]); cmd.set_color('ncol',[0.19,0.35,0.85]); cmd.set_color('ocol',[0.88,0.16,0.16])
def scene(tag, view):
    style()
    cmd.load(f'{tag}_{view}_au.pdb','au'); cmd.load(f'{tag}_{view}_mol.pdb','mol')
    cmd.show_as('spheres','au'); cmd.alter('au','vdw=1.44'); cmd.set('sphere_scale',0.62,'au'); cmd.color('aucol','au')
    cmd.show_as('sticks','mol'); cmd.show('spheres','mol'); cmd.set('sphere_scale',0.25,'mol'); cmd.set('sphere_scale',0.17,'mol and elem H')
    cmd.color('ccol','mol and elem C'); cmd.color('ncol','mol and elem N'); cmd.color('ocol','mol and elem O'); cmd.color('white','mol and elem H')
    cmd.rebuild(); cmd.reset()
    if view=='side':
        cmd.turn('x',10)
        for k,(x,y) in enumerate([(-9.8,0.0),(9.8,0.0),(-9.8,13.0),(9.8,13.0)]): cmd.pseudoatom(f'bx{k}',pos=[x,y,0.0])
    else:
        for k,(x,y) in enumerate([(-9.8,-5.5),(9.8,-5.5),(-9.8,5.5),(9.8,5.5)]): cmd.pseudoatom(f'bx{k}',pos=[x,y,2.0])
    cmd.zoom('bx*',0.0); cmd.delete('bx*')
    w,h=(1600,1050) if view=='side' else (1600,1000)
    cmd.png(f'{tag}_{view}.png',width=w,height=h,dpi=300,ray=1); print(tag,view,'ok')
for t in ('FA','PCA'):
    for v in ('side','top'): scene(t,v)

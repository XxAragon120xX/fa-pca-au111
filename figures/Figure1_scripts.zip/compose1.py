import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Times New Roman', 'Liberation Serif'], 'mathtext.fontset': 'stix',
                     'font.size': 9, 'pdf.fonttype': 42})
def load(f):
    a = np.array(Image.open(f).convert('RGB')); m = (a > 238).all(-1); a[m] = 255; return a
fig = plt.figure(figsize=(7.2, 4.6))
gs = fig.add_gridspec(2, 2, height_ratios=[1050, 1000], hspace=0.04, wspace=0.03, left=0.01, right=0.99, top=0.90, bottom=0.01)
P = [('FA', 'a', 'FA/Au(111), V-Z-Pt', '−1.516 eV (−34.96 kcal mol$^{-1}$)'),
     ('PCA', 'b', 'PCA/Au(111), F-B', '−0.990 eV (−22.84 kcal mol$^{-1}$)')]
for col, (tag, let, name, e) in enumerate(P):
    for row, view in enumerate(('side', 'top')):
        ax = fig.add_subplot(gs[row, col]); ax.imshow(load(f'{tag}_{view}.png')); ax.set_xticks([]); ax.set_yticks([])
        for s in ax.spines.values(): s.set_color('#c9c8c2'); s.set_linewidth(0.6)
        ax.text(0.015, 0.97 if view == 'side' else 0.96, 'side view' if view == 'side' else 'top view', transform=ax.transAxes,
                va='top', fontsize=8, color='#52514e', style='italic',
                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none', alpha=0.8) if view == 'top' else None)
        if row == 0:
            ax.set_title(f'({let})  {name}', loc='left', fontsize=10, pad=14)
            ax.text(0.0, 1.015, f'Δ$E_{{\\rm ads}}$ = {e}', transform=ax.transAxes, fontsize=8.5, color='#52514e', va='bottom')
for ext in ('png', 'pdf', 'tiff'):
    fig.savefig(f'Figure1_geometrias.{ext}', dpi=600)
fig.savefig('prev_fig1.png', dpi=140); print('ok')

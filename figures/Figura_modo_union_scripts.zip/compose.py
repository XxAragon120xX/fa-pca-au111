import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image, ImageChops
from matplotlib.patches import Patch
INK, INK2 = '#0b0b0b', '#52514e'
plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Times New Roman', 'Liberation Serif', 'TeX Gyre Termes'], 'mathtext.fontset': 'stix', 'font.size': 8.5, 'pdf.fonttype': 42, 'ps.fonttype': 42})
def autocrop(im, pad=20):
    bg = Image.new(im.mode, im.size, (255, 255, 255)); diff = ImageChops.difference(im, bg).convert('L').point(lambda p: 255 if p > 12 else 0)
    b = diff.getbbox(); return im.crop((max(b[0]-pad, 0), max(b[1]-pad, 0), min(b[2]+pad, im.width), min(b[3]+pad, im.height)))
def whiten(im):
    a = np.array(im); m = (a > 238).all(-1); a[m] = 255; return Image.fromarray(a)
A = whiten(Image.open('panel_a.png').convert('RGB').crop((300, 600, 2100, 1400)))
Bp = whiten(autocrop(Image.open('panel_b.png').convert('RGB'))); Cp = whiten(autocrop(Image.open('panel_c.png').convert('RGB')))
info = np.load('info.npy'); anc = np.load('anchor.npy')
fig = plt.figure(figsize=(7.2, 7.3))
gs = fig.add_gridspec(2, 2, height_ratios=[0.86, 1.0], hspace=0.22, wspace=0.04, left=0.01, right=0.99, top=0.95, bottom=0.07)
ax = fig.add_subplot(gs[0, :]); ax.imshow(A); ax.axis('off')
ax.set_title('PCA (F-B) on Au(111): flat physisorption, no Au–N bond', loc='left', fontsize=8.5, color=INK, pad=4)
ax.text(-0.005, 1.06, 'a', transform=ax.transAxes, fontsize=12, fontweight='bold', va='bottom')
for (x, y), (tx, ty), txt in [((446, 468), (150, 120), 'N(NH$_2$)···Au  3.18 Å'), ((605, 446), (520, 40), 'H(N3–H)···Au  2.46 Å'),
                              ((829, 425), (990, 120), 'O(C4=O)···Au  2.85 Å')]:
    ax.annotate(txt, xy=(x, y), xytext=(tx, ty), fontsize=7.5, color=INK, ha='center',
                arrowprops=dict(arrowstyle='-', color=INK2, lw=0.7, shrinkA=2, shrinkB=4),
                bbox=dict(boxstyle='round,pad=0.25', fc='white', ec='none', alpha=0.85))
ax.legend(handles=[Patch(color='#d92626', alpha=0.8, label='Δρ > 0 (accumulation)'), Patch(color='#2666e6', alpha=0.8, label='Δρ < 0 (depletion)')],
          loc='lower right', bbox_to_anchor=(1.0, 1.0), ncol=2, frameon=False, fontsize=7, handlelength=1.2, columnspacing=1.0)
ax.text(0.0, -0.025, 'Δρ isosurfaces ±0.0015 e bohr$^{-3}$ · all contacts at about the van der Waals distance · |Δq| ≤ 0.05 e per atom (Bader)', transform=ax.transAxes, ha='left', va='top', fontsize=7, color=INK2)
bx = fig.add_subplot(gs[1, 0]); bx.imshow(Bp); bx.axis('off')
bx.set_title('PCA (F-B): FRα placed on its pterin', loc='left', fontsize=8.5, pad=4)
bx.text(-0.01, 1.04, 'b', transform=bx.transAxes, fontsize=12, fontweight='bold', va='bottom')
bx.text(0.5, -0.01, '%d of 1,697 receptor atoms (%.0f%%) inside the metal\n→ no recognition possible' % (info[2], 100*info[3]),
        transform=bx.transAxes, ha='center', va='top', fontsize=7.5, color='#b3141e')
cx = fig.add_subplot(gs[1, 1]); cx.imshow(Cp); cx.axis('off')
cx.set_title('FA anchored through its glutamate', loc='left', fontsize=8.5, pad=4)
cx.text(-0.04, 1.04, 'c', transform=cx.transAxes, fontsize=12, fontweight='bold', va='bottom')
cx.text(0.5, -0.01, 'FRα ≥ 3.0 Å above Au · pterin %.1f Å above the surface\nγ-carboxylate O %.1f Å above Au → recognition compatible' % (anc[4], anc[3]),
        transform=cx.transAxes, ha='center', va='top', fontsize=7.5, color='#1f6b45')
bx.legend(handles=[Patch(color='#9ec7eb', label='FRα'), Patch(color='#db2633', label='atoms inside Au / < 2.5 Å')], loc='upper left', frameon=False, fontsize=6.8, bbox_to_anchor=(0.0, 0.98))
for ext, kw in (('png', {'dpi': 600}), ('pdf', {'dpi': 600}), ('tiff', {'dpi': 600})):
    fig.savefig(f'out/Figura_modo_union.{ext}', **kw)
fig.savefig('prev_full.png', dpi=150)
print('ok')

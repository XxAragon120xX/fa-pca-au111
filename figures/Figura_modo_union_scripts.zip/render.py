from pymol import cmd
import numpy as np
W, H = 1800, 1350
def base():
    cmd.reinitialize()
    cmd.bg_color('white')
    for k, v in [('ray_trace_mode', 1), ('ray_trace_gain', 0.06), ('antialias', 2), ('ray_shadows', 1), ('ambient', 0.45),
                 ('specular', 0.25), ('spec_power', 120), ('light_count', 2), ('depth_cue', 0), ('orthoscopic', 1),
                 ('stick_radius', 0.17), ('sphere_scale', 0.24), ('stick_ball', 1), ('stick_ball_ratio', 1.7),
                 ('dash_gap', 0.28), ('dash_length', 0.32), ('dash_radius', 0.075), ('dash_color', 'black'),
                 ('label_size', 26), ('label_color', 'black'), ('label_font_id', 7), ('float_labels', 1),
                 ('ray_trace_color', 'grey20'), ('cartoon_transparency', 0.0), ('transparency_mode', 3)]:
        cmd.set(k, v)
    cmd.set_color('aucol', [0.93, 0.74, 0.25]); cmd.set_color('ccol', [0.55, 0.55, 0.55])
    cmd.set_color('ncol', [0.19, 0.35, 0.85]); cmd.set_color('ocol', [0.88, 0.16, 0.16])
    cmd.set_color('prot', [0.62, 0.78, 0.92]); cmd.set_color('clash', [0.86, 0.15, 0.20])
    cmd.set_color('acc', [0.85, 0.15, 0.15]); cmd.set_color('dep', [0.15, 0.40, 0.90])
def mol_style(sel):
    cmd.show_as('sticks', sel); cmd.show('spheres', sel)
    cmd.color('ccol', f'{sel} and elem C'); cmd.color('ncol', f'{sel} and elem N'); cmd.color('ocol', f'{sel} and elem O'); cmd.color('white', f'{sel} and elem H')
    cmd.set('sphere_scale', 0.24, sel); cmd.set('sphere_scale', 0.16, f'{sel} and elem H')
def au_style(sel, scale=0.9):
    cmd.show_as('spheres', sel); cmd.color('aucol', sel); cmd.set('sphere_scale', scale, sel); cmd.alter(sel, 'vdw=1.44'); cmd.rebuild()

# ---------------- panel a: PCA F-B + Δρ
base()
cmd.load('au_local.pdb', 'au'); cmd.load('pca.pdb', 'pca'); cmd.load('drho_ortho.cube', 'drho')
au_style('au', 0.62); mol_style('pca')
cmd.isosurface('iso_p', 'drho', 0.0015); cmd.isosurface('iso_m', 'drho', -0.0015)
cmd.color('acc', 'iso_p'); cmd.color('dep', 'iso_m'); cmd.set('transparency', 0.35, 'iso_p'); cmd.set('transparency', 0.35, 'iso_m')
cmd.delete('drho_*'); cmd.hide('everything', 'drho and not iso*') if False else None
for a, b, nm in [(20, 131, 'd1'), (14, 136, 'd2'), (1, 126, 'd3')]:
    cmd.distance(nm, f'pca and id {a}', f'au and id {b}')
cmd.hide('labels'); cmd.color('black', 'd*')
cmd.orient('pca'); cmd.turn('x', -90); cmd.turn('x', 28); cmd.turn('y', 15)
cmd.zoom('pca', 3.2)
cmd.move('y', -1.5)
cmd.png('panel_a.png', width=W, height=H, dpi=300, ray=1)
cmd.get_view()
np.save('view_a.npy', np.array(cmd.get_view()))
print('a ok')

from pymol import cmd
import numpy as np
exec(open('render.py').read().split('# ---------------- panel a')[0])
base()
cmd.load('v_au_a.pdb', 'au'); cmd.load('v_pca.pdb', 'pca'); cmd.load('v_drho.cube', 'drho')
au_style('au', 0.55); mol_style('pca')
lev = 0.0015
cmd.isosurface('iso_p', 'drho', lev); cmd.isosurface('iso_m', 'drho', -lev)
cmd.color('acc', 'iso_p'); cmd.color('dep', 'iso_m')
cmd.set('transparency', 0.30, 'iso_p'); cmd.set('transparency', 0.30, 'iso_m')
def rdx(fn): return np.array([[float(l[30:38]),float(l[38:46]),float(l[46:54])] for l in open(fn) if l.startswith(('ATOM','HETATM'))])
A = rdx('v_au_a.pdb'); Mx = rdx('v_pca.pdb')
for k, (aid, nm) in enumerate([(20, 'H'), (14, 'O'), (1, 'N')]):
    p = Mx[aid-1]; j = int(np.argmin(((A-p)**2).sum(1)))
    print(nm, round(float(np.linalg.norm(A[j]-p)), 2))
    cmd.pseudoatom(f'au{k}', pos=[float(x) for x in A[j]]); cmd.distance(f'd{k}', f'pca and id {aid}', f'au{k}'); cmd.hide('everything', f'au{k}')
cmd.hide('labels'); cmd.color('black', 'd*')
cmd.reset(); cmd.turn('x', 18)
cmd.zoom('pca', 2.0); cmd.move('y', -0.8)
cmd.png('panel_a.png', width=2400, height=1500, dpi=300, ray=1)
import json; json.dump({'view': list(cmd.get_view()), 'fov': float(cmd.get('field_of_view')), 'W': 2400, 'H': 1500}, open('view_a.json', 'w'))
# coordenadas de pantalla aproximadas de los contactos para rotular después
print('a ok')

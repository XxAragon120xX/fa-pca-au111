from pymol import cmd
import numpy as np
exec(open('render.py').read().split('# ---------------- panel a')[0])
def rdx(fn): return np.array([[float(l[30:38]),float(l[38:46]),float(l[46:54])] for l in open(fn) if l.startswith(('ATOM','HETATM'))])
def slab(name):
    cmd.load('v_au_big.pdb', name)
    cmd.remove(f'{name} and (z > 1.5 or z < -26 or x < -34 or x > 34)')
    au_style(name, 0.62)
def protein(fn, name):
    cmd.load(fn, name); cmd.hide('everything', name)
    cmd.show('cartoon', name); cmd.color('prot', name)
    cmd.show('surface', name); cmd.set('transparency', 0.55, name); cmd.set('surface_quality', 1)
    cmd.set('cartoon_transparency', 0.0)
# ---------------- panel b
base(); slab('au'); protein('v_frα_on_pca_b.pdb', 'fra')
cmd.color('clash', 'fra and b > 0.5'); cmd.set('surface_color', 'prot', 'fra')
cmd.create('clashsurf', 'fra and b > 0.5'); cmd.hide('everything', 'clashsurf'); cmd.show('surface', 'clashsurf')
cmd.set('surface_color', 'clash', 'clashsurf'); cmd.set('transparency', 0.25, 'clashsurf')
cmd.load('v_pca.pdb', 'pca'); mol_style('pca')
cmd.reset(); cmd.turn('x', 6); cmd.zoom('fra or pca', 2.0)
cmd.png('panel_b.png', width=1800, height=1800, dpi=300, ray=1); print('b ok')
# ---------------- panel c
base(); slab('au'); protein('v_frα_on_fa.pdb', 'fra'); cmd.set('surface_color', 'prot', 'fra')
cmd.load('v_fa_anchored.pdb', 'fa'); mol_style('fa'); cmd.color('forest', 'fa and elem C')
a = np.load('anchor_v.npy')
cmd.pseudoatom('o1', pos=[float(a[0]), float(a[1]), float(a[2])]); cmd.pseudoatom('s1', pos=[float(a[0]), 0.0, float(a[2])])
cmd.distance('dt', 'o1', 's1'); cmd.hide('labels'); cmd.hide('nonbonded', 'o1 or s1'); cmd.color('black', 'dt')
cmd.set('dash_radius', 0.12, 'dt')
cmd.reset(); cmd.turn('x', 6); cmd.zoom('fra or fa', 2.0)
cmd.png('panel_c.png', width=1800, height=1800, dpi=300, ray=1); print('c ok')

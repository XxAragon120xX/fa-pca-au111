import numpy as np
exec(open('build.py').read().split('# ---------- FA anclado')[0].replace("print(", "(lambda *a, **k: None)("))
fa = pH.GetConformer().GetPositions(); fel = [a.GetSymbol() for a in pH.GetAtoms()]
carb = [a.GetIdx() for a in pS.GetAtoms() if a.GetSymbol() == 'C' and sum(nb.GetSymbol() == 'O' for nb in a.GetNeighbors()) == 2]
pter_c = P.mean(0); gC = max(carb, key=lambda k: np.linalg.norm(fa[k] - pter_c))
gO = [nb.GetIdx() for nb in pS.GetAtomWithIdx(gC).GetNeighbors() if nb.GetSymbol() == 'O']
def rot(q):
    q = q/np.linalg.norm(q); w, x, y, z = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
rng = np.random.default_rng(7); best = None
for _ in range(300000):
    Rr = rot(rng.normal(size=4)); pz = pxyz @ Rr[2]; fz = fa @ Rr[2]
    surf = pz.min() - 3.0
    if fz.min() < surf + 2.0: continue
    hO = fz[gO].min() - surf
    if fz[gO].min() > fz.min() + 1e-6: continue           # Oγ = átomo más bajo del FA
    if best is None or hO < best[0]: best = (hO, Rr, surf, fz[list(cp)].mean() - surf)
hO, Rr, surf, hpt = best
print('Orientación con receptor a 3.0 Å: altura Oγ = %.2f Å, pterina = %.2f Å' % (hO, hpt))
shift = ztop - surf
fac = fa @ Rr.T; fac[:, 2] += shift; pc = pxyz @ Rr.T; pc[:, 2] += shift
off = c[:2] - fac[:, :2].mean(0); fac[:, :2] += off; pc[:, :2] += off
write_pdb('fa_anchored.pdb', fel, fac, 'FOL'); place(pc, 'frα_on_fa.pdb')
o = min(gO, key=lambda k: fac[k, 2]); np.save('anchor.npy', np.r_[fac[o], hO, hpt])
print('Oγ xyz', fac[o])

import numpy as np
from scipy.ndimage import map_coordinates
B = 0.529177210903
def rd(fn):
    L=[l for l in open(fn) if l.startswith(('ATOM','HETATM'))]
    return L, np.array([[float(l[30:38]),float(l[38:46]),float(l[46:54])] for l in L])
def wr(fn, L, X):
    with open(fn,'w') as f:
        for l, r in zip(L, X): f.write(l[:30] + '%8.3f%8.3f%8.3f' % tuple(r) + l[54:])
        f.write('END\n')
Lm, M = rd('pca.pdb'); c = M.mean(0)
# eje largo de la molécula en el plano
u, s, vt = np.linalg.svd((M - c)[:, :2]); ax = np.r_[vt[0], 0.0]
ex = ax / np.linalg.norm(ax); ey = np.array([0, 0, 1.0]); ez = np.cross(ex, ey)
R = np.vstack([ex, ey, ez])                    # world -> view
ztop = np.load('info.npy')[4]
o = np.array([c[0], c[1], ztop])
tv = lambda X: (X - o) @ R.T
wr('v_pca.pdb', Lm, tv(M))
cell = np.load('cell.npy')
La, A = rd('au_big.pdb'); Av = tv(A)
mv = tv(M)
box = (Av[:, 0] > mv[:, 0].min()-7) & (Av[:, 0] < mv[:, 0].max()+7) & (np.abs(Av[:, 2]) < 9)
wr('v_au_a.pdb', [La[0]]*box.sum(), Av[box])
for fn in ('frα_on_pca.pdb', 'frα_on_fa.pdb', 'fa_anchored.pdb', 'au_big.pdb'):
    L, X = rd(fn); wr('v_' + fn, L, tv(X))
np.save('anchor_v.npy', tv(np.load('anchor.npy')[:3][None])[0])
# Δρ remuestreado en el marco de vista
C = open('/mnt/user-data/uploads/Au/Figura_union/drho_FB_recortado.cube').read().split('\n')
nat = abs(int(C[2].split()[0])); org = np.array(C[2].split()[1:4], float)
n = [int(C[3+i].split()[0]) for i in range(3)]; v = np.array([C[3+i].split()[1:4] for i in range(3)], float)
d = np.fromstring(' '.join(C[6+nat:]), sep=' ').reshape(n)
h = 0.12
lo = np.array([mv[:, 0].min()-4, -2.5, mv[:, 2].min()-4]); hi = np.array([mv[:, 0].max()+4, mv[:, 1].max()+3, mv[:, 2].max()+4])
g = [np.arange(lo[i], hi[i], h) for i in range(3)]
G = np.stack(np.meshgrid(*g, indexing='ij'), -1)
W = G @ R + o                                   # view -> world (Å)
Mi = np.linalg.inv(np.array([[v[0, 0], v[1, 0]], [v[0, 1], v[1, 1]]]))
xb, yb, zb = W[..., 0]/B - org[0], W[..., 1]/B - org[1], W[..., 2]/B - org[2]
ii = Mi[0, 0]*xb + Mi[0, 1]*yb; jj = Mi[1, 0]*xb + Mi[1, 1]*yb; kk = zb / v[2, 2]
vals = map_coordinates(d, [ii.ravel(), jj.ravel(), kk.ravel()], order=1, mode='grid-wrap').reshape(G.shape[:3])
with open('v_drho.cube', 'w') as f:
    f.write('drho view\nA\n%5d %12.6f %12.6f %12.6f\n' % (1, *(lo/B)))
    for k, m in enumerate(vals.shape):
        vv = [0, 0, 0]; vv[k] = h/B; f.write('%5d %12.6f %12.6f %12.6f\n' % (m, *vv))
    f.write('%5d %12.6f %12.6f %12.6f %12.6f\n' % (1, 0, 0, 0, 0))
    for row in vals.reshape(-1, vals.shape[2]):
        for j in range(0, len(row), 6): f.write(' '.join('%13.5E' % x for x in row[j:j+6]) + '\n')
print('ok', vals.shape, box.sum(), 'Au en panel a')

import re, numpy as np
from scipy.ndimage import map_coordinates
from scipy.spatial import cKDTree
from rdkit import Chem
from rdkit.Chem import rdDetermineBonds
from Bio.PDB import PDBParser, PDBIO
B = 0.529177210903
U = '/mnt/user-data/uploads/Au/'
# ---------- geometría DFT
L = open(U + 'Figura_union/PCA_FB_A.in').read().splitlines()
cell = None; pos = []
for i, ln in enumerate(L):
    s = ln.strip().upper()
    if s.startswith('CELL_PARAMETERS'):
        cell = np.array([[float(x) for x in L[i+k].split()[:3]] for k in (1, 2, 3)])
    if s.startswith('ATOMIC_POSITIONS'):
        j = i + 1
        while j < len(L) and re.match(r'^\s*[A-Za-z]{1,2}\s+-?\d', L[j]):
            t = L[j].split(); pos.append((t[0], *map(float, t[1:4]))); j += 1
el = np.array([p[0] for p in pos]); X = np.array([p[1:] for p in pos])
au = X[el == 'Au']; mol = X[el != 'Au']; mel = el[el != 'Au']
ztop = au[:, 2][au[:, 2] > au[:, 2].max() - 0.6].mean()
print('Au', len(au), 'mol', len(mol), 'ztop', round(ztop, 3))
np.save('cell.npy', cell)

def write_pdb(fn, els, xyz, resn='MOL', hetatm=True, bfac=None):
    with open(fn, 'w') as f:
        for k, (e, r) in enumerate(zip(els, xyz), 1):
            b = 0.0 if bfac is None else bfac[k-1]
            f.write('%-6s%5d %-4s %3s A   1    %8.3f%8.3f%8.3f  1.00%6.2f          %2s\n' % (
                'HETATM' if hetatm else 'ATOM', k % 100000, e, resn, *r, b, e))
        f.write('END\n')

# molécula y slab local (panel a)
write_pdb('pca.pdb', mel, mol, 'PCA')
c = mol.mean(0)
img = np.vstack([au + i*cell[0] + j*cell[1] for i in range(-2, 3) for j in range(-2, 3)])
loc = img[(np.abs(img[:, 0]-c[0]) < 9.5) & (np.abs(img[:, 1]-c[1]) < 8.0)]
write_pdb('au_local.pdb', ['Au']*len(loc), loc, 'AU')

# ---------- Δρ en malla ortogonal alrededor de la molécula
C = open(U + 'Figura_union/drho_FB_recortado.cube').read().split('\n')
nat = abs(int(C[2].split()[0])); org = np.array(C[2].split()[1:4], float)
n = [int(C[3+i].split()[0]) for i in range(3)]; v = np.array([C[3+i].split()[1:4] for i in range(3)], float)
d = np.fromstring(' '.join(C[6+nat:]), sep=' ').reshape(n)
print('Δρ min/max', d.min(), d.max())
h = 0.15
lo = np.array([c[0]-9.0, c[1]-7.5, ztop-2.5]); hi = np.array([c[0]+9.0, c[1]+7.5, mol[:, 2].max()+3.0])
gx = np.arange(lo[0], hi[0], h); gy = np.arange(lo[1], hi[1], h); gz = np.arange(lo[2], hi[2], h)
Gx, Gy, Gz = np.meshgrid(gx, gy, gz, indexing='ij')
Mi = np.linalg.inv(np.array([[v[0, 0], v[1, 0]], [v[0, 1], v[1, 1]]]))
xb, yb, zb = Gx/B - org[0], Gy/B - org[1], Gz/B - org[2]
ii = Mi[0, 0]*xb + Mi[0, 1]*yb; jj = Mi[1, 0]*xb + Mi[1, 1]*yb; kk = zb / v[2, 2]
vals = map_coordinates(d, [ii.ravel(), jj.ravel(), kk.ravel()], order=1, mode='grid-wrap').reshape(Gx.shape)
with open('drho_ortho.cube', 'w') as f:
    f.write('drho ortho\nA\n%5d %12.6f %12.6f %12.6f\n' % (1, *(lo/B)))
    for k, m in enumerate(vals.shape):
        vv = [0, 0, 0]; vv[k] = h/B; f.write('%5d %12.6f %12.6f %12.6f\n' % (m, *vv))
    f.write('%5d %12.6f %12.6f %12.6f %12.6f\n' % (1, 0, *(c/B)))
    flat = vals.reshape(-1, vals.shape[2])
    for row in flat:
        for j in range(0, len(row), 6): f.write(' '.join('%13.5E' % x for x in row[j:j+6]) + '\n')
print('cube ortho', vals.shape, vals.min(), vals.max())

# ---------- alineamiento docking -> PCA (pterina, 12 átomos)
def skel(m):
    m.UpdatePropertyCache(strict=False); m = Chem.RemoveHs(m, sanitize=False); rw = Chem.RWMol(m)
    for b in rw.GetBonds(): b.SetBondType(Chem.BondType.SINGLE); b.SetIsAromatic(False)
    for a in rw.GetAtoms(): a.SetFormalCharge(0); a.SetIsAromatic(False); a.SetNumExplicitHs(0); a.SetNoImplicit(True)
    return rw.GetMol(), m
core = Chem.MolFromSmarts('[#7]~[#6]1~[#7]~[#6]2~[#7]~[#6]~[#6]~[#7]~[#6]2~[#6](~[#8])~[#7]~1')
qe = Chem.MolFromXYZBlock('%d\nPCA\n' % len(mol) + '\n'.join('%s %.6f %.6f %.6f' % (e, *p) for e, p in zip(mel, mol)))
rdDetermineBonds.DetermineConnectivity(qe)
qS, qH = skel(qe)
pose = Chem.SDMolSupplier(U + 'Docking/FA_pose1_caja18.sdf', removeHs=False)[0]
pS, pH = skel(pose)
cq = qS.GetSubstructMatch(core); cp = pS.GetSubstructMatch(core)
print('match', len(cq), len(cp))
Q = qH.GetConformer().GetPositions()[list(cq)]; P = pH.GetConformer().GetPositions()[list(cp)]
def kabsch(P, Q):
    Pc, Qc = P.mean(0), Q.mean(0); H = (P-Pc).T @ (Q-Qc); Uu, S, Vt = np.linalg.svd(H)
    dd = np.sign(np.linalg.det(Vt.T @ Uu.T)); R = Vt.T @ np.diag([1, 1, dd]) @ Uu.T
    return R, Qc - R @ Pc
R, t = kabsch(P, Q)
print('RMSD pterina', np.sqrt(((P @ R.T + t - Q)**2).sum(1).mean()))
prot = PDBParser(QUIET=True).get_structure('p', U + 'Docking/proteina.pdb')
atoms = list(prot.get_atoms()); pxyz = np.array([a.coord for a in atoms], float)
big = np.vstack([au + i*cell[0] + j*cell[1] for i in range(-4, 5) for j in range(-4, 5)])
def place(xyz, fn):
    for a, r in zip(atoms, xyz): a.set_coord(r.astype('float32'))
    io = PDBIO(); io.set_structure(prot); io.save(fn)
pb = pxyz @ R.T + t
dmin, _ = cKDTree(big).query(pb)
below = pb[:, 2] < ztop
print('PCA F-B + FRα: átomos bajo el plano', below.sum(), '(%.0f%%)' % (100*below.mean()), ' <2.5 Å de Au', (dmin < 2.5).sum())
place(pb, 'frα_on_pca.pdb')
np.save('clash_mask.npy', (below | (dmin < 2.5)))
# slab grande centrado en la molécula para panel b
c2 = pb.mean(0)
bigc = big[(np.abs(big[:, 0]-c[0]) < 30) & (np.abs(big[:, 1]-c[1]) < 30)]
write_pdb('au_big.pdb', ['Au']*len(bigc), bigc, 'AU')

# ---------- FA anclado por el γ-carboxilato (panel c)
fa = pH.GetConformer().GetPositions(); fel = [a.GetSymbol() for a in pH.GetAtoms()]
# carboxilos: C con dos O; γ = el más lejano (topológicamente) del N amida
carb = [a.GetIdx() for a in pS.GetAtoms() if a.GetSymbol() == 'C' and sum(nb.GetSymbol() == 'O' for nb in a.GetNeighbors()) == 2]
dm = Chem.GetDistanceMatrix(pS)
nam = [a.GetIdx() for a in pS.GetAtoms() if a.GetSymbol() == 'N' and a.GetDegree() == 2 and a.GetIdx() not in cp]
pter_c = P.mean(0)
gC = max(carb, key=lambda k: np.linalg.norm(fa[k] - pter_c))
gO = [nb.GetIdx() for nb in pS.GetAtomWithIdx(gC).GetNeighbors() if nb.GetSymbol() == 'O']
print('carboxilos', carb, 'gamma C', gC, 'dist centroide-Oγ', [round(np.linalg.norm(fa[o]-pter_c), 2) for o in gO])
allx = np.vstack([pxyz, fa])
rng = np.random.default_rng(1); best = None
def rot(q):
    q = q/np.linalg.norm(q); w, x, y, z = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
for _ in range(200000):
    Rr = rot(rng.normal(size=4)); fr = fa @ Rr.T; o = min(gO, key=lambda k: fr[k, 2])
    if fr[:, 2].min() < fr[o, 2] - 1e-6: continue          # el Oγ debe ser el átomo más bajo del FA
    shift = ztop + 2.2 - fr[o, 2]
    pz = (pxyz @ Rr.T)[:, 2] + shift
    clear = pz.min() - ztop
    if best is None or clear > best[0]: best = (clear, Rr, shift, (fr[list(cp)].mean(0)[2] + shift) - ztop)
clear, Rr, shift, hpt = best
print('FA anclado: separación mínima proteína-superficie %.2f Å, altura pterina %.2f Å' % (clear, hpt))
fac = fa @ Rr.T; fac[:, 2] += shift; pc = pxyz @ Rr.T; pc[:, 2] += shift
off = c[:2] - fac[:, :2].mean(0); fac[:, :2] += off; pc[:, :2] += off
write_pdb('fa_anchored.pdb', fel, fac, 'FOL')
place(pc, 'frα_on_fa.pdb')
np.save('info.npy', np.array([clear, hpt, below.sum(), below.mean(), ztop]))

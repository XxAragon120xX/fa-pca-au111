import sys; sys.path.insert(0,'../SI')
from origin_style import apply
import matplotlib.pyplot as plt, matplotlib.image as mpimg
from matplotlib.gridspec import GridSpec
apply()
ab=mpimg.imread('Figure10_ab.png'); c=mpimg.imread('panel_c.png'); d=mpimg.imread('panel_d.png')
W=12.2
wsp=0.05
h_top = W*ab.shape[0]/ab.shape[1]                 # fila a,b a ancho completo
w_half = (W - 0.1)/2                              # cada panel inferior
h_bot = w_half*c.shape[0]/c.shape[1]
lab_h, gap = 0.34, 0.30
H = h_top + gap + h_bot + lab_h
fig=plt.figure(figsize=(W,H))
gs=GridSpec(2,2,height_ratios=[h_top, h_bot+lab_h],hspace=gap/H*2.2,wspace=wsp,figure=fig)
a0=fig.add_subplot(gs[0,:]); a0.imshow(ab); a0.axis('off')
for j,(img,letter,lab) in enumerate([(c,'c','FA$^{3-}$  (FA-tail, $t$ = 200 ns)'),
                                     (d,'d','PCA$^{2-}$  (PCA-sol-1, $t$ = 200 ns)')]):
    ax=fig.add_subplot(gs[1,j]); ax.imshow(img); ax.axis('off')
    ax.text(0.01,1.0,f'({letter})',transform=ax.transAxes,fontsize=14,fontweight='bold',va='bottom')
    ax.text(0.5,-0.09,lab,transform=ax.transAxes,fontsize=11.5,ha='center',va='top')
plt.subplots_adjust(left=0.004,right=0.996,top=0.995,bottom=lab_h/H*0.8)
for ext in ('png','pdf'): plt.savefig(f'Figure10.{ext}',dpi=600,bbox_inches='tight')
print('ok')

from pymol import cmd
from PIL import Image, ImageChops
import numpy as np

def setup(tag):
    cmd.reinitialize()
    cmd.load(f'raw/{tag}_final.pdb','sys'); cmd.hide('everything')
    cmd.remove('resn NA or resn CL or resn SOD or resn CLA or elem Na or elem Cl')
    cmd.select('au','resn AU'); cmd.select('lig','not au')
    cmd.show('spheres','au'); cmd.color('gold','au'); cmd.set('sphere_scale',0.75,'au')
    cmd.show('sticks','lig'); cmd.util.cbay('lig'); cmd.set('stick_radius',0.22)
    cmd.show('spheres','lig'); cmd.set('sphere_scale',0.28,'lig')
    cmd.bg_color('white')
    for k,v in [('ray_opaque_background',1),('antialias',2),('ray_shadows',0),
                ('specular',0.25),('depth_cue',0),('ambient',0.22),('orthoscopic',1)]:
        cmd.set(k,v)
    cmd.reset(); cmd.turn('x',-90)

# vista de referencia a partir del ligando mas grande (FA)
setup('fa3_tail1'); cmd.zoom('lig',7.5)
REF=list(cmd.get_view())

def centroid(sel='lig'):
    xs=[]
    cmd.iterate_state(1,sel,'xs.append((x,y,z))',space={'xs':xs})
    return np.array(xs).mean(axis=0)

for tag,out in [('fa3_tail1','panel_c.png'),('pc2_sol1','panel_d.png')]:
    setup(tag)
    v=REF[:]; c=centroid()
    v[12],v[13],v[14]=float(c[0]),float(c[1]),float(c[2])   # misma escala, centro en el ligando
    cmd.set_view(v)
    cmd.ray(2400,1150); cmd.png(out,dpi=600)
    print(tag,'->',out)

# recorte vertical comun
boxes=[]
for f in ('panel_c.png','panel_d.png'):
    im=Image.open(f).convert('RGB')
    boxes.append(ImageChops.difference(im,Image.new('RGB',im.size,(255,255,255))).getbbox())
top=max(0,min(b[1] for b in boxes)-18); bot=min(1150,max(b[3] for b in boxes)+18)
for f in ('panel_c.png','panel_d.png'):
    im=Image.open(f).convert('RGB'); im.crop((0,top,im.width,bot)).save(f)
    print(f,Image.open(f).size)

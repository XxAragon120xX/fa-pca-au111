import sys, numpy as np, pandas as pd
sys.path.insert(0,'../SI')
from origin_style import apply, OK, OR, OB, OG
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
apply()
MAG='#CC00CC'
FA=[('fa3_flat1','FA-flat',OK),('fa3_sol1','FA-sol-1',OR),('fa3_sol2','FA-sol-2',OB),
    ('fa3_sol3','FA-sol-3',OG),('fa3_tail1','FA-tail',MAG)]
PC=[('pc2_flat1','PCA-flat',OK),('pc2_sol1','PCA-sol-1',OR),('pc2_sol2','PCA-sol-2',OB),('pc2_sol3','PCA-sol-3',OG)]
sm=lambda y,w=100: pd.Series(y).rolling(w,center=True,min_periods=1).mean().values
YMAX=35; TB=20.0   # break at 20 ns
fig=plt.figure(figsize=(12.2,4.3))
gs=GridSpec(1,5,width_ratios=[2.6,1.5,0.45,2.6,1.5],wspace=0.08,figure=fig)
def block(j,sets,letter,ylab):
    aL=fig.add_subplot(gs[0,j]); aR=fig.add_subplot(gs[0,j+1],sharey=aL)
    for d,name,c in sets:
        df=pd.read_csv(f'raw/{d}/an_au/serie.csv'); y=sm(df.h_pterina)
        aL.plot(df.t_ns,y,color=c,lw=1.5); aR.plot(df.t_ns,y,color=c,lw=1.5,label=name)
    for a in (aL,aR):
        a.axhline(15.1,color='0.45',ls='--',lw=1.3); a.set_ylim(0,YMAX)
    aL.set_xlim(0,TB); aL.set_xticks([0,5,10,15,20])
    aR.set_xlim(TB,200); aR.set_xticks([50,100,150,200])
    aL.spines['right'].set_visible(False); aR.spines['left'].set_visible(False)
    aR.tick_params(labelleft=False,left=False)
    for x in (1,-1):  # break marks
        aL.plot([1],[x*0.5+0.5],transform=aL.transAxes,marker=[(-1,-.4),(1,.4)],ms=9,mew=1.5,
                color='k',clip_on=False,ls='none')
        aR.plot([0],[x*0.5+0.5],transform=aR.transAxes,marker=[(-1,-.4),(1,.4)],ms=9,mew=1.5,
                color='k',clip_on=False,ls='none')
    aL.text(0.06,0.96,f'({letter})',transform=aL.transAxes,fontsize=14,fontweight='bold',va='top')
    aR.text(198,15.9,'minimum height for FR'+r'$\alpha$'+' binding',fontsize=9.5,color='0.35',va='bottom',ha='right')
    aR.legend(loc='upper right',fontsize=10,labelspacing=0.3)
    if ylab: aL.set_ylabel('Pterin height above Au(111) ('+r'$\mathrm{\AA}$'+')')
    return aL,aR
block(0,FA,'a',True); block(3,PC,'b',False)
fig.supxlabel('Time (ns)',fontsize=14,fontweight='bold',y=0.02)
fig.subplots_adjust(left=0.075,right=0.99,top=0.97,bottom=0.17)
for ext in ('png','pdf'): plt.savefig(f'Figure10_ab.{ext}',bbox_inches='tight')
print('ok')

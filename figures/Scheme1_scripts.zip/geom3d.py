import sys; sys.path.insert(0,'/tmp/claude-0/-home-claude/55059600-48b1-535c-9792-8006a72a8889/scratchpad/scheme')
from rdkit import Chem
from rdkit.Chem import AllChem
import frags, json, numpy as np
FA=Chem.MolFromSmiles('Nc1nc2ncc(CNc3ccc(cc3)C(=O)N[C@@H](CCC(O)=O)C(O)=O)nc2c(=O)[nH]1')
PCA=Chem.MolFromSmiles('Nc1nc2ncc(C(=O)O)nc2c(=O)[nH]1')
out={}
for tag,m,fn in (('FA',FA,frags.fragments_FA),('PCA',PCA,frags.fragments_PCA)):
    pm,fr=fn(m)                                   # indices sobre el grafo sin H
    mh=Chem.AddHs(m)
    cids=AllChem.EmbedMultipleConfs(mh,numConfs=60,randomSeed=20261112,pruneRmsThresh=0.5)
    res=AllChem.MMFFOptimizeMoleculeConfs(mh,maxIters=2000)
    # elegir la conformacion mas extendida (no la de minima energia): un esquema
    # estructural se lee mejor con los tres fragmentos separados
    pt=[i for i in fr['pterin']]
    tail=[i for i in (fr['glu'] if fr['glu'] else fr['pABA'])]
    span=[]
    for ci in cids:
        c=mh.GetConformer(ci)
        P=np.array([[c.GetAtomPosition(i).x,c.GetAtomPosition(i).y,c.GetAtomPosition(i).z] for i in pt]).mean(0)
        Tl=np.array([[c.GetAtomPosition(i).x,c.GetAtomPosition(i).y,c.GetAtomPosition(i).z] for i in tail]).mean(0)
        span.append(np.linalg.norm(P-Tl))
    best=int(np.argmax(span))
    print('   extension pterina-cola: %.1f A (max de %d confs)'%(span[best],len(cids)))
    conf=mh.GetConformer(cids[best])
    # escribir PDB con numeracion de atomos pesados preservada (AddHs mantiene el orden)
    lines=[]
    for i,a in enumerate(mh.GetAtoms()):
        p=conf.GetAtomPosition(i)
        lines.append('HETATM%5d %-4s %3s A   1    %8.3f%8.3f%8.3f  1.00  0.00          %2s'
                     %(i+1,a.GetSymbol()+str(i+1),tag[:3],p.x,p.y,p.z,a.GetSymbol()))
    open(f'{tag}_3d.pdb','w').write('\n'.join(lines)+'\nEND\n')
    # serials (1-based) por fragmento y por etiqueta
    hs={}
    for i,a in enumerate(mh.GetAtoms()):
        if a.GetSymbol()=='H':
            hs.setdefault(a.GetNeighbors()[0].GetIdx(),[]).append(i)
    def grp(idxs):
        s=set(idxs)
        for i in list(idxs): s.update(hs.get(i,[]))
        return sorted(x+1 for x in s)
    out[tag]={'frag':{k:grp(v) for k,v in fr.items() if v},
              'lab':{k:v+1 for k,v in pm.items()},
              'E':round(min(e for conv,e in res),2)}
    print(tag,'confs',len(cids),'E_MMFF %.2f kcal/mol'%out[tag]['E'],'atomos',mh.GetNumAtoms())
json.dump(out,open('geom3d.json','w'))

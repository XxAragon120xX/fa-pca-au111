import json, numpy as np
from pymol import cmd
G=json.load(open('geom3d.json'))
BLUE=[0.45,0.68,0.90]; ORANGE=[0.97,0.70,0.36]; GREEN=[0.56,0.80,0.52]
REF={'d':None,'clip':None}
LAB=['O4','C4','N3','N5','N1','N8','C9','N10','Calpha_COOH','Cgamma_COOH','COOH']
def sel(ids): return 'id '+'+'.join(map(str,ids))
def scene(tag,W,H):
    cmd.reinitialize(); cmd.bg_color('white')
    for k,v in [('ray_trace_mode',1),('ray_trace_gain',0.06),('ray_trace_color','grey25'),
                ('antialias',2),('ray_shadows',0),('ambient',0.42),('specular',0.28),
                ('spec_power',120),('orthoscopic',1),('depth_cue',0),('two_sided_lighting',1),
                ('stick_radius',0.13),('transparency_mode',3),('surface_quality',1),
                ('solvent_radius',1.15),('ray_opaque_background',1)]:
        cmd.set(k,v)
    cmd.set_color('ccol',[0.40,0.40,0.42]); cmd.set_color('ncol',[0.19,0.35,0.85]); cmd.set_color('ocol',[0.88,0.16,0.16])
    cmd.set_color('fblue',BLUE); cmd.set_color('forange',ORANGE); cmd.set_color('fgreen',GREEN)
    cmd.load(f'{tag}_3d.pdb','m')
    cmd.show_as('sticks','m'); cmd.show('spheres','m')
    cmd.set('sphere_scale',0.21); cmd.set('sphere_scale',0.13,'elem H')
    cmd.color('ccol','elem C'); cmd.color('ncol','elem N'); cmd.color('ocol','elem O'); cmd.color('white','elem H')
    for name,col in (('pterin','fblue'),('pABA','forange'),('glu','fgreen')):
        ids=G[tag]['frag'].get(name)
        if not ids: continue
        cmd.create(f'env_{name}',sel(ids)); cmd.show_as('surface',f'env_{name}')
        cmd.color(col,f'env_{name}'); cmd.set('transparency',0.66,f'env_{name}')
    cmd.orient('m'); cmd.turn('x',-8)
    def cen(ids):
        xs=[]; cmd.iterate_state(1,sel(ids),'xs.append((x,y,z))',space={'xs':xs}); return np.array(xs).mean(0)
    R=np.array(cmd.get_view()[:9]).reshape(3,3)
    other=G[tag]['frag'].get('glu') or G[tag]['frag']['pABA']
    if (cen(G[tag]['frag']['pterin'])-cen(other)) @ R[0] > 0: cmd.turn('y',180)
    cmd.zoom('m',1.2)
    view=list(cmd.get_view())
    if REF['d'] is None: REF['d']=view[11]; REF['clip']=(view[15],view[16])
    else:
        # misma escala que el primer panel: conservar rotacion y centro, igualar la distancia
        k=REF['d']/view[11]
        view[11]=REF['d']; view[15],view[16]=view[15]*k,view[16]*k
    cmd.set_view(view)
    cmd.ray(W,H); cmd.png(f'{tag}_3d.png',dpi=600)
    # --- imagen de marcadores en la misma vista, para localizar los atomos ---
    keys=[k for k in LAB if k in G[tag]['lab']]
    cmd.delete('all'); cmd.load(f'{tag}_3d.pdb','m2'); cmd.hide('everything')
    cols={}
    for i,k in enumerate(keys):
        c=[(i*53%251)/255.,(i*97%251)/255.,(i*149%251)/255.]
        cmd.set_color(f'mk{i}',c); cols[k]=tuple(round(x*255) for x in c)
        s=f"id {G[tag]['lab'][k]}"
        cmd.show('spheres',s); cmd.set('sphere_scale',0.34,s); cmd.color(f'mk{i}',s)
    cmd.set('ray_trace_mode',0); cmd.set('ray_shadows',0); cmd.set('ambient',1.0); cmd.set('specular',0)
    cmd.set_view(view); cmd.ray(W,H); cmd.png(f'{tag}_mk.png',dpi=600)
    json.dump(cols,open(f'{tag}_cols.json','w'))
    print(tag,'ok',len(keys),'etiquetas')
scene('FA',2600,1700); scene('PCA',1500,1700)

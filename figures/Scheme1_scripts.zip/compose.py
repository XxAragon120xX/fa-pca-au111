import sys
sys.path.insert(0,'/tmp/claude-0/-home-claude/55059600-48b1-535c-9792-8006a72a8889/scratchpad/SI')
import json, numpy as np, matplotlib.pyplot as plt, matplotlib.image as mpimg
from matplotlib.gridspec import GridSpec
from matplotlib.patches import Patch
from origin_style import apply
apply()
D=json.load(open('coords.json'))
imF=mpimg.imread('fa.png'); imP=mpimg.imread('pca.png')
BLUE='#B0D6F2'; ORANGE='#FDD6A3'; GREEN='#C7E6C2'

def place(ax,key,labels,texts={},ovr={}):
    C=D[key]['coords']; L=D[key]['lab']; N=D[key]['nbrs']
    for lab in labels:
        if lab not in L: continue
        idx=L[lab]; p=np.array(C[str(idx)])
        o=ovr.get(lab,{})
        if 'dir' in o:
            v=np.array(o['dir'],dtype=float)
        else:
            nb=[np.array(C[str(j)]) for j in N[str(idx)]]
            v=p-np.mean(nb,axis=0) if nb else np.array([0.,-1.])
        n=np.linalg.norm(v); v=v/n if n>1e-6 else np.array([0.,-1.])
        q=p+v*o.get('R',78)
        ax.text(q[0],q[1],texts.get(lab,lab),fontsize=16,ha=o.get('ha','center'),
                va='center',color='#1a1a1a',zorder=6)

PT=['N1','N3','C4','O4','N5','C6','C7','N8']
# C4 hacia arriba-derecha, al hueco entre O4 y N5
COMMON={'C4':{'dir':(-0.55,-0.95),'R':95}}
OF=dict(COMMON); OF.update({'C9':{'dir':(0,-1),'R':70},
    'Calpha_COOH':{'dir':(0.95,-0.75),'R':128,'ha':'left'},
    'Cgamma_COOH':{'dir':(1,0.22),'R':165,'ha':'left'}})
OP=dict(COMMON); OP.update({'COOH':{'dir':(1,-0.35),'R':95,'ha':'left'}})

fig=plt.figure(figsize=(13.4,4.5))
gs=GridSpec(2,2,width_ratios=[imF.shape[1],imP.shape[1]],height_ratios=[1,0.12],
            wspace=0.03,hspace=0.0,figure=fig)
for col,(im,key,labs,txt,ovr,letter,name) in enumerate([
    (imF,'FA',PT+['C9','N10','Calpha_COOH','Cgamma_COOH'],
     {'Calpha_COOH':'α-COOH','Cgamma_COOH':'γ-COOH'},OF,'a','folic acid (FA)'),
    (imP,'PCA',PT+['COOH'],{'COOH':'COOH'},OP,'b','pterin-6-carboxylic acid (PCA)')]):
    ax=fig.add_subplot(gs[0,col]); ax.imshow(im); ax.axis('off')
    ax.set_xlim(-0.06*im.shape[1], 1.10*im.shape[1])
    ax.set_ylim(im.shape[0]*1.20, -im.shape[0]*0.14)
    place(ax,key,labs,txt,ovr)
    ax.text(0.0,1.0,f'({letter})',transform=ax.transAxes,fontsize=18,fontweight='bold',va='top')
    ax.text(0.5,0.015,name,transform=ax.transAxes,fontsize=13.5,ha='center',va='bottom')
axl=fig.add_subplot(gs[1,:]); axl.axis('off')
axl.legend(handles=[Patch(facecolor=BLUE,label='pterin'),
                    Patch(facecolor=ORANGE,label='p-aminobenzoyl (FA) / carboxylic group (PCA)'),
                    Patch(facecolor=GREEN,label='glutamate (FA)')],
           loc='center',ncol=3,frameon=False,fontsize=12.5,handlelength=1.5,columnspacing=2.4)
plt.subplots_adjust(left=0.004,right=0.996,top=0.995,bottom=0.005)
for e in ('png','pdf'): plt.savefig(f'Scheme1.{e}',dpi=600,bbox_inches='tight')
print('ok')

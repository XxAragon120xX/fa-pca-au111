import sys; sys.path.insert(0,'/tmp/claude-0/-home-claude/55059600-48b1-535c-9792-8006a72a8889/scratchpad/scheme')
from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Chem.Draw import rdMolDraw2D
import frags, io
from PIL import Image

BLUE=(0.69,0.84,0.95); ORANGE=(0.99,0.84,0.64); GREEN=(0.78,0.90,0.76)
FA=Chem.MolFromSmiles('Nc1nc2ncc(CNc3ccc(cc3)C(=O)N[C@@H](CCC(O)=O)C(O)=O)nc2c(=O)[nH]1')
PCA=Chem.MolFromSmiles('Nc1nc2ncc(C(=O)O)nc2c(=O)[nH]1')

def render(m,fr,W,H,fixed=95):
    AllChem.Compute2DCoords(m)
    hi={}; 
    for s,c in ((fr['pterin'],BLUE),(fr['pABA'],ORANGE),(fr['glu'],GREEN)):
        for i in s: hi[i]=c
    hb={}
    for b in m.GetBonds():
        i,j=b.GetBeginAtomIdx(),b.GetEndAtomIdx()
        for s,c in ((fr['pterin'],BLUE),(fr['pABA'],ORANGE),(fr['glu'],GREEN)):
            if i in s and j in s: hb[b.GetIdx()]=c
    d=rdMolDraw2D.MolDraw2DCairo(W,H)
    o=d.drawOptions()
    o.fixedBondLength=fixed; o.highlightRadius=0.38; o.bondLineWidth=3
    o.highlightBondWidthMultiplier=22; o.minFontSize=40; o.maxFontSize=40
    o.additionalAtomLabelPadding=0.10
    rdMolDraw2D.PrepareAndDrawMolecule(d,m,highlightAtoms=list(hi),highlightAtomColors=hi,
                                       highlightBonds=list(hb),highlightBondColors=hb)
    d.FinishDrawing()
    img=Image.open(io.BytesIO(d.GetDrawingText()))
    coords={i:tuple(d.GetDrawCoords(i)) for i in range(m.GetNumAtoms())}
    nbrs={i:[a.GetIdx() for a in m.GetAtomWithIdx(i).GetNeighbors()] for i in range(m.GetNumAtoms())}
    return img,coords,nbrs

pmF,frF=frags.fragments_FA(FA); pmP,frP=frags.fragments_PCA(PCA)
imF,cF,nF=render(FA,frF,2900,1000); imP,cP,nP=render(PCA,frP,1500,1000)
from PIL import ImageChops
def crop(im,co):
    bb=ImageChops.difference(im.convert('RGB'),Image.new('RGB',im.size,(255,255,255))).getbbox()
    p=70; bb=(max(0,bb[0]-p),max(0,bb[1]-p),min(im.width,bb[2]+p),min(im.height,bb[3]+p))
    return im.crop(bb), {k:(v[0]-bb[0],v[1]-bb[1]) for k,v in co.items()}
imF,cF=crop(imF,cF); imP,cP=crop(imP,cP)
imF.save('fa.png'); imP.save('pca.png')
import json; json.dump({'FA':{'coords':{str(k):v for k,v in cF.items()},'lab':pmF,'nbrs':{str(k):v for k,v in nF.items()}},
           'PCA':{'coords':{str(k):v for k,v in cP.items()},'lab':pmP,'nbrs':{str(k):v for k,v in nP.items()}}},open('coords.json','w'))
print('FA',imF.size,'PCA',imP.size)

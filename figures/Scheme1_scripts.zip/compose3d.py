import sys; sys.path.insert(0,'/tmp/claude-0/-home-claude/55059600-48b1-535c-9792-8006a72a8889/scratchpad/SI')
import json, numpy as np, matplotlib.pyplot as plt, matplotlib.image as mpimg
from matplotlib.gridspec import GridSpec
from matplotlib.patches import Patch
from PIL import Image, ImageChops
from origin_style import apply
apply()
BLUE='#73AEE6'; ORANGE='#F7B35C'; GREEN='#8FCC85'
TXT={'Calpha_COOH':'α-COOH','Cgamma_COOH':'γ-COOH','COOH':'COOH'}
def prep(tag):
    im=Image.open(f'{tag}_3d.png').convert('RGB'); mk=Image.open(f'{tag}_mk.png').convert('RGB')
    cols=json.load(open(f'{tag}_cols.json'))
    A=np.array(mk).astype(int); pos={}
    for k,c in cols.items():
        d=np.abs(A-np.array(c)).sum(-1)
        ys,xs=np.where(d<26)
        if len(xs): pos[k]=(xs.mean(),ys.mean())
    bb=ImageChops.difference(im,Image.new('RGB',im.size,(255,255,255))).getbbox()
    p=36; bb=(max(0,bb[0]-p),max(0,bb[1]-p),min(im.width,bb[2]+p),min(im.height,bb[3]+p))
    im=im.crop(bb); pos={k:(x-bb[0],y-bb[1]) for k,(x,y) in pos.items()}
    return np.array(im),pos
iF,pF=prep('FA'); iP,pP=prep('PCA')
OV={'FA':{'N10':{'d':(0,-1)},'C9':{'d':(-0.3,1)},'N5':{'d':(0,-1)},'N8':{'d':(0,-1)},
          'N1':{'d':(-0.95,0.3)},'N3':{'d':(-0.5,1),'R':105},'O4':{'d':(0.1,1)},'C4':{'d':(0.85,0.55),'R':100},
          'Calpha_COOH':{'d':(0.4,1),'R':120},'Cgamma_COOH':{'d':(0.6,-1),'R':120}},
    'PCA':{'N10':{'d':(0,-1)},'N5':{'d':(0,-1)},'N8':{'d':(0,-1)},'N1':{'d':(-0.5,1)},
           'N3':{'d':(-1,-0.5)},'O4':{'d':(0,1)},'COOH':{'d':(0.7,-0.7),'R':120}}}
fig=plt.figure(figsize=(13.4,4.6))
gs=GridSpec(2,2,width_ratios=[iF.shape[1],iP.shape[1]],height_ratios=[1,0.13],
            wspace=0.03,hspace=0.0,figure=fig)
for col,(im,pos,ov,letter,name) in enumerate([
    (iF,pF,OV['FA'],'a','folic acid (FA)'),(iP,pP,OV['PCA'],'b','pterin-6-carboxylic acid (PCA)')]):
    ax=fig.add_subplot(gs[0,col]); ax.imshow(im); ax.axis('off')
    ax.set_xlim(-0.05*im.shape[1],1.07*im.shape[1]); ax.set_ylim(im.shape[0]*1.16,-im.shape[0]*0.13)
    for k,(x,y) in pos.items():
        o=ov.get(k,{}); v=np.array(o.get('d',(0,-1)),float); v/=np.linalg.norm(v)
        q=(x,y)+v*o.get('R',95)
        ax.text(q[0],q[1],TXT.get(k,k),fontsize=15,ha='center',va='center',color='#141414',zorder=6)
    ax.text(0.0,1.0,f'({letter})',transform=ax.transAxes,fontsize=18,fontweight='bold',va='top')
    ax.text(0.5,0.015,name,transform=ax.transAxes,fontsize=13.5,ha='center',va='bottom')
axl=fig.add_subplot(gs[1,:]); axl.axis('off')
axl.legend(handles=[Patch(facecolor=BLUE,label='pterin'),
                    Patch(facecolor=ORANGE,label='p-aminobenzoyl (FA) / carboxylic group (PCA)'),
                    Patch(facecolor=GREEN,label='glutamate (FA)')],
           loc='center',ncol=3,frameon=False,fontsize=12.5,handlelength=1.5,columnspacing=2.4)
plt.subplots_adjust(left=0.004,right=0.996,top=0.995,bottom=0.005)
for e in ('png','pdf'): plt.savefig(f'Scheme1_3D.{e}',dpi=600,bbox_inches='tight')
print('etiquetas FA',len(pF),'PCA',len(pP))

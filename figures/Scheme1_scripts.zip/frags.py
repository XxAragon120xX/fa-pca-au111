from rdkit import Chem
Q=Chem.MolFromSmiles('Nc1nc2nccnc2c(=O)[nH]1')
NAMES=['N2amino','C2','N1','C8a','N8','C7','C6','N5','C4a','C4','O4','N3']
def pterin_map(m):
    mt=m.GetSubstructMatch(Q)
    return {NAMES[k]:i for k,i in enumerate(mt)}, set(mt)

def fragments_FA(m):
    pm,pt=pterin_map(m)
    C9=[a.GetIdx() for a in m.GetAtomWithIdx(pm['C6']).GetNeighbors() if a.GetIdx() not in pt][0]
    N10=[a.GetIdx() for a in m.GetAtomWithIdx(C9).GetNeighbors() if a.GetIdx()!=pm['C6']][0]
    ring=[r for r in m.GetRingInfo().AtomRings()
          if len(r)==6 and all(m.GetAtomWithIdx(i).GetIsAromatic() for i in r) and not set(r)&pt
          and any(N10 in [n.GetIdx() for n in m.GetAtomWithIdx(i).GetNeighbors()] for i in r)][0]
    # carbono amida: unido al anillo, con O doble y un N
    amideC=[a.GetIdx() for i in ring for a in m.GetAtomWithIdx(i).GetNeighbors()
            if a.GetIdx() not in ring and a.GetSymbol()=='C'
            and any(n.GetSymbol()=='O' for n in a.GetNeighbors())][0]
    amideO=[a.GetIdx() for a in m.GetAtomWithIdx(amideC).GetNeighbors()
            if a.GetSymbol()=='O'][0]
    amideN=[a.GetIdx() for a in m.GetAtomWithIdx(amideC).GetNeighbors()
            if a.GetSymbol()=='N'][0]
    pABA=set(ring)|{N10,amideC,amideO}
    glu=set(range(m.GetNumAtoms()))-pt-{C9}-pABA
    # Calfa, y los dos carboxilos
    Ca=[a.GetIdx() for a in m.GetAtomWithIdx(amideN).GetNeighbors() if a.GetIdx()!=amideC][0]
    cooh=[i for i in glu if m.GetAtomWithIdx(i).GetSymbol()=='C'
          and sum(1 for n in m.GetAtomWithIdx(i).GetNeighbors() if n.GetSymbol()=='O')==2]
    alpha=[c for c in cooh if Ca in [n.GetIdx() for n in m.GetAtomWithIdx(c).GetNeighbors()]][0]
    gamma=[c for c in cooh if c!=alpha][0]
    pm.update(C9=C9,N10=N10,Calpha=Ca,Calpha_COOH=alpha,Cgamma_COOH=gamma)
    return pm,{'pterin':pt,'pABA':pABA,'glu':glu}

def fragments_PCA(m):
    pm,pt=pterin_map(m)
    C=[a.GetIdx() for a in m.GetAtomWithIdx(pm['C6']).GetNeighbors() if a.GetIdx() not in pt][0]
    Os={a.GetIdx() for a in m.GetAtomWithIdx(C).GetNeighbors() if a.GetSymbol()=='O'}
    pm.update(COOH=C)
    return pm,{'pterin':pt,'pABA':{C}|Os,'glu':set()}

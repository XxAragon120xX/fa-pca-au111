import re, sys, numpy as np, json
sys.path.insert(0,'/home/claude/dock/pca')
from scipy.spatial import cKDTree
from rdkit import Chem
from rdkit.Chem import rdDetermineBonds
from analiza import skel, core
D='/home/claude/fig3d/'; PC='/home/claude/dock/pca/'
def rd(fn):
    L=[l for l in open(fn) if l.startswith(('ATOM','HETATM'))]
    return L,np.array([[float(l[30:38]),float(l[38:46]),float(l[46:54])] for l in L])
def wr(fn,L,X,bf=None):
    with open(fn,'w') as f:
        for k,(l,r) in enumerate(zip(L,X)):
            b=0.0 if bf is None else bf[k]
            f.write(l[:30]+'%8.3f%8.3f%8.3f'%tuple(r)+l[54:60].ljust(6)+'%6.2f'%b+l[66:].rstrip('\n')+'\n')
        f.write('END\n')
def readqe(fn):
    L=open(fn).read().splitlines(); pos=[]
    for i,l in enumerate(L):
        s=l.strip().upper()
        if s.startswith('CELL_PARAMETERS'): cell=np.array([[float(x) for x in L[i+k].split()[:3]] for k in (1,2,3)])
        if s.startswith('ATOMIC_POSITIONS'):
            j=i+1
            while j<len(L) and re.match(r'^\s*[A-Za-z]{1,2}\s+-?\d',L[j]): t=L[j].split(); pos.append((t[0],*map(float,t[1:4]))); j+=1
    return np.array([p[0] for p in pos]),np.array([p[1:] for p in pos]),cell
def kabsch(P,Q):
    Pc,Qc=P.mean(0),Q.mean(0); H=(P-Pc).T@(Q-Qc); U_,S,Vt=np.linalg.svd(H)
    d=np.sign(np.linalg.det(Vt.T@U_.T)); R=Vt.T@np.diag([1,1,d])@U_.T; return R,Qc-R@Pc
el,X,cell=readqe('/mnt/user-data/uploads/Au/Figura_union/PCA_flat_B_down_A.in')
au=X[el=='Au']; mol=X[el!='Au']; me=el[el!='Au']; print('nAu',len(au),'nmol',len(mol))
qe=Chem.MolFromXYZBlock('%d\nx\n'%len(mol)+'\n'.join('%s %.6f %.6f %.6f'%(e,*p) for e,p in zip(me,mol)))
rdDetermineBonds.DetermineConnectivity(qe); qS,qH=skel(qe); Q=qH.GetConformer().GetPositions()[list(qS.GetSubstructMatch(core))]
pose=Chem.MolFromPDBFile(PC+'PCA_pose6.pdb',removeHs=False); pS,pH=skel(pose); P=pH.GetConformer().GetPositions()[list(pS.GetSubstructMatch(core))]
R,t=kabsch(P,Q); print('fit rmsd',np.sqrt(((P@R.T+t-Q)**2).sum(1).mean()).round(3))
Lp,P0=rd(PC+'proteina.pdb'); Pb=P0@R.T+t
big=np.vstack([au+i*cell[0]+j*cell[1] for i in range(-6,7) for j in range(-6,7)])
ztop=au[:,2].max(); ztm=au[:,2][au[:,2]>ztop-1].mean()
d,_=cKDTree(big).query(Pb); below=Pb[:,2]<ztop; close=d<2.5
print('below',below.sum(),'(%.0f%%)'%(100*below.mean()),' <2.5',close.sum(),' dmin',d.min().round(2),' pterin h',(Q.mean(0)[2]-ztm).round(2))
res=[(l[21],l[22:27]) for l in Lp]; bad={res[k] for k in np.where(below|close)[0]}
bf=[1.0 if r in bad else 0.0 for r in res]
# panel c from earlier model (same Au frame z)
Lc,Pc=rd(D+'frα_on_fa.pdb'); Lf,F=rd(D+'fa_anchored.pdb'); anc=np.load(D+'anchor.npy')
# shift c so its xy sits over the same slab (it is a flat-surface model); keep z
u,s,vt=np.linalg.svd((Pb-Pb.mean(0))[:,:2]); ex=np.r_[vt[0],0]; ex/=np.linalg.norm(ex); ey=np.array([0,0,1.]); ez=np.cross(ex,ey); Rv=np.vstack([ex,ey,ez])
out={}
pt_c=F[:12].mean(0)
for tag,Pp,Lx,lig,Ll,ctr in (('b',Pb,Lp,mol,None,Q.mean(0)),('c',Pc,Lc,F,Lf,pt_c)):
    o=np.array([ctr[0],ctr[1],ztm]); tv=lambda Y:(Y-o)@Rv.T
    pv=tv(Pp); wr(f'v_{tag}_prot.pdb',Lx,pv,bf if tag=='b' else None)
    if tag=='b':
        with open('v_b_lig.pdb','w') as f:
            for k,(e,x) in enumerate(zip(me,tv(lig))): f.write('HETATM%5d %-4s PCA L   1    %8.3f%8.3f%8.3f  1.00  0.00          %2s\n'%(k+1,e,*x,e))
            f.write('END\n')
    else: wr('v_c_lig.pdb',Ll,tv(lig))
    Av=tv(big); keep=(Av[:,0]>-34)&(Av[:,0]<34)&(Av[:,2]<pv[:,2].mean()+24)&(Av[:,2]>pv[:,2].mean()-30)
    with open(f'v_{tag}_au.pdb','w') as f:
        for k,x in enumerate(Av[keep]): f.write('HETATM%5d Au    AU S   1    %8.3f%8.3f%8.3f  1.00  0.00          Au\n'%(k+1,*x))
        f.write('END\n')
    out[tag]=dict(xmin=float(pv[:,0].min()),xmax=float(pv[:,0].max()),ymin=float(pv[:,1].min()),ymax=float(pv[:,1].max()),zc=float(pv[:,2].mean()))
    if tag=='c': out['c']['anchor']=tv(anc[:3][None])[0].tolist(); out['c']['pter_h']=float(tv(pt_c[None])[0][1])
out['b']['below']=int(below.sum()); out['b']['close']=int(close.sum()); out['b']['pct']=float(100*below.mean())
json.dump(out,open('ext.json','w'),indent=1); print(json.dumps(out,indent=1))

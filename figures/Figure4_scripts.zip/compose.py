import numpy as np, json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from PIL import Image
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif'],'mathtext.fontset':'stix','font.size':8.5,'pdf.fonttype':42})
INK,INK2='#0b0b0b','#3a3a3a'; S=25.0; X0=-30.0; Y0=-23.0
E=json.load(open('ext.json')); anc=np.load('/home/claude/fig3d/anchor.npy')
def white(a): a=np.array(a.convert('RGB')); a[(a>238).all(-1)]=255; return a
A=white(Image.open('/home/claude/fig3d/panel_a.png').crop((300,600,2100,1400)))
B=white(Image.open('panel_b.png')); C=white(Image.open('panel_c.png'))
FW,FH=7.2,8.3; fig=plt.figure(figsize=(FW,FH))
# top: panel a
wa=7.0; ha=wa*A.shape[0]/A.shape[1]; ya=FH-0.3-ha
ax=fig.add_axes([0.1/FW,ya/FH,wa/FW,ha/FH]); ax.imshow(A); ax.axis('off')
ax.text(0,1.04,'a',transform=ax.transAxes,fontsize=12,fontweight='bold',va='bottom')
ax.text(0.04,1.04,'PCA (F-B) on Au(111): flat physisorption, no Au–N bond',transform=ax.transAxes,fontsize=8.5,va='bottom')
for (x,y),(tx,ty),txt in [((446,468),(150,120),'N(NH$_2$)···Au  3.18 Å'),((605,446),(520,40),'H(N3–H)···Au  2.46 Å'),((829,425),(990,120),'O(C4=O)···Au  2.85 Å')]:
    ax.annotate(txt,xy=(x,y),xytext=(tx,ty),fontsize=7.5,ha='center',arrowprops=dict(arrowstyle='-',color=INK2,lw=0.7,shrinkA=2,shrinkB=4),
                bbox=dict(boxstyle='round,pad=0.25',fc='white',ec='none',alpha=0.85))
ax.legend(handles=[Patch(color='#d92626',alpha=0.8,label='Δρ > 0 (accumulation)'),Patch(color='#2666e6',alpha=0.8,label='Δρ < 0 (depletion)')],
          loc='lower right',bbox_to_anchor=(1.0,1.0),ncol=2,frameon=False,fontsize=7,handlelength=1.2)
ax.text(0,-0.02,'Δρ isosurfaces ±0.0015 e bohr$^{-3}$ · all contacts at about the van der Waals distance · |Δq| ≤ 0.05 e per atom (Bader)',transform=ax.transAxes,va='top',fontsize=7,color=INK2)
# bottom: b and c at the same scale, slab bottoms aligned
sc=3.45/B.shape[1]; yb=0.45
wb,hb=B.shape[1]*sc,B.shape[0]*sc; wc,hc=C.shape[1]*sc,C.shape[0]*sc
bx=fig.add_axes([0.1/FW,yb/FH,wb/FW,hb/FH]); bx.imshow(B); bx.axis('off')
cx=fig.add_axes([3.7/FW,yb/FH,wc/FW,hc/FH]); cx.imshow(C); cx.axis('off')
for a,l,t in ((bx,'b','PCA (F-B): FRα placed on its pterin'),(cx,'c','FA anchored through its glutamate')):
    a.text(0,1.0,l,transform=a.transAxes,fontsize=12,fontweight='bold',va='bottom'); a.text(0.07,1.0,t,transform=a.transAxes,fontsize=8.5,va='bottom')
eb=E['b']; bx.text(0.98,0.02,f'{eb["below"]} of 1,697 receptor atoms ({eb["pct"]:.0f}%) below the Au plane\n{eb["close"]} atoms < 2.5 Å from Au → no recognition possible',
    transform=bx.transAxes,ha='right',va='bottom',fontsize=7.3,color='#b3141e',bbox=dict(fc='white',ec='none',alpha=0.85,pad=1.5))
y1c=45.0; px=lambda x:(x-X0)*S; py=lambda y:(y1c-y)*S
hp=float(anc[4]); xa=px(-27.0)
cx.annotate('',xy=(xa,py(0)),xytext=(xa,py(hp)),arrowprops=dict(arrowstyle='<->',color='black',lw=0.9))
cx.plot([xa-12,px(0)],[py(hp)]*2,ls=(0,(3,2)),color='black',lw=0.7)
cx.text(xa+16,py(hp/2),f'pterin\n{hp:.1f} Å',fontsize=7.5,va='center',bbox=dict(fc='white',ec='none',alpha=0.85,pad=1))
cx.text(0.98,0.02,f'FRα ≥ 3.0 Å above Au · γ-carboxylate O {anc[3]:.1f} Å above Au\n→ recognition compatible',transform=cx.transAxes,ha='right',va='bottom',fontsize=7.3,color='#1f6b45',bbox=dict(fc='white',ec='none',alpha=0.85,pad=1.5))
fig.legend(handles=[Patch(color='#9ec7eb',label='FRα (cartoon)'),Patch(color='#db2633',label='residues inside Au or < 2.5 Å from Au'),
    Line2D([],[],color='#ff8c26',lw=2.2,label='PCA'),Line2D([],[],color='#228b22',lw=2.2,label='FA'),Patch(color='#efb53a',label='Au(111)')],
    loc='lower center',ncol=5,frameon=False,fontsize=7.3,bbox_to_anchor=(0.5,0.0),handlelength=1.3,columnspacing=1.0)
for e,kw in (('png',{'dpi':600}),('pdf',{'dpi':600})): fig.savefig(f'Figure4_binding_mode.{e}',**kw)
fig.savefig('prev4.png',dpi=120); print('ok')

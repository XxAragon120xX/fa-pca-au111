import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OK,OR,OB,OG='#000000','#FF0000','#0000FF','#008000'   # Origin default sequence
def apply():
    plt.rcParams.update({
        'font.family':'serif','font.serif':['Times New Roman','Liberation Serif'],'mathtext.fontset':'stix',
        'font.size':11,'axes.linewidth':1.5,'axes.labelweight':'bold','axes.labelsize':14,
        'xtick.direction':'out','ytick.direction':'out','xtick.top':False,'ytick.right':False,
        'xtick.major.size':5,'ytick.major.size':5,'xtick.major.width':1.5,'ytick.major.width':1.5,
        'xtick.minor.visible':False,'ytick.minor.visible':False,'xtick.labelsize':12,'ytick.labelsize':12,
        'legend.frameon':False,'legend.fontsize':11,'legend.handlelength':2.2,'lines.linewidth':1.6,
        'pdf.fonttype':42,'savefig.dpi':600})
def panel(ax,letter):
    ax.text(0.03,0.96,f'({letter})',transform=ax.transAxes,fontsize=14,fontweight='bold',va='top',ha='left')

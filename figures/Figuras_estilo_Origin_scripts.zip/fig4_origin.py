import numpy as np, sys
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/stda_run')
import origin_style as S; S.apply()
import matplotlib.pyplot as plt
from spec_lib import states
R='/home/claude/stda_run/'
x=np.linspace(3.0,6.2,4000); s=0.10; lam=1239.84/x
g=lambda E,F:(F[:,None]*np.exp(-(x-E[:,None])**2/(2*s*s))).sum(0)
cent={'pca0Au16':4.390,'pca2mAu16':4.311}; ref={'free':4.448,'pca0_ads':4.377,'pca2m_free':4.326,'pca2m_ads':4.243}
fig,axs=plt.subplots(1,2,figsize=(10,4.2),sharey=True,gridspec_kw={'wspace':0.08})
for a,(let,lab,au,fr,ad) in zip(axs,[('a','Neutral PCA','pca0Au16','free','pca0_ads'),('b','PCA dianion','pca2mAu16','pca2m_free','pca2m_ads')]):
    E,F=states(R+au+'/out_v.txt'); P=np.load(R+au+'/proj.npy'); n=P.shape[1]; E,F,W=E[:n],F[:n],P[3]
    a.plot(lam,g(*states(R+fr+'/out.txt')),color=S.OK,label='Free')
    a.plot(lam,g(*states(R+ad+'/out.txt')),color=S.OR,label='Adsorbed geometry')
    a.plot(lam,3*g(E,F*W),color=S.OB,label='Adsorbed + Au$_{\\mathbf{16}}$ (×3)')
    for e,c in [(ref[fr],S.OK),(ref[ad],S.OR),(cent[au],S.OB)]: a.axvline(1239.84/e,ymax=0.70,color=c,lw=1.0,ls=':')
    a.set_xlim(230,380); a.set_ylim(0,0.80); a.set_xlabel('λ (nm)')
    a.text(0.03,0.96,f'({let}) {lab}',transform=a.transAxes,fontsize=13,fontweight='bold',va='top')
    a.legend(loc='upper right',fontsize=10.5)
axs[0].set_ylabel('Oscillator strength (a.u.)')
for e in ('png','pdf','tiff'): fig.savefig(f'Figure4_UV_PCA_origin.{e}',bbox_inches='tight')

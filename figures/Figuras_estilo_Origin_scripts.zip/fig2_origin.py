import re, numpy as np, sys
sys.path.insert(0,'.')
import origin_style as S; S.apply()
import matplotlib.pyplot as plt
D='/mnt/user-data/uploads/Au/'
ef_of=lambda p: float(re.search(r'E_F - E_vac = ([-\d.]+)',open(p).readline()).group(1))
fig,ax=plt.subplots(1,2,figsize=(10,4.2),sharey=True,gridspec_kw={'wspace':0.08})
for a,(tag,sub,rest,let) in zip(ax,[('FA','DoS FA','Rest of FA','a'),('PCA','DoS PCA','COOH','b')]):
    q=np.loadtxt(f'{D}{sub}/{tag}_pdos_complex.dat'); ef=ef_of(f'{D}{sub}/{tag}_dos_complex.dat')
    a.axvspan(ef+0.4,ef+1.0,ymax=0.76,color='#d9d9d9',lw=0,zorder=0)
    a.fill_between(q[:,0],0.2*q[:,3],color='#b0b0b0',alpha=0.55,lw=0,label='Au top layer d (×0.2)')
    a.plot(q[:,0],np.clip(q[:,1],0,None),color=S.OR,label='Pterin')
    a.plot(q[:,0],np.clip(q[:,2],0,None),color=S.OB,label=rest)
    a.axvline(ef,ymax=0.76,color='k',ls='--',lw=1.2)
    a.text(ef-0.12,0.66,r'$\mathbf{E_F}$',transform=a.get_xaxis_transform(),fontsize=13,ha='right',va='top')
    a.set_xlim(-13,-1); a.set_xticks(range(-12,0,2)); a.set_xlabel(r'$\mathbf{E-E_{vac}}$ (eV)')
    a.text(0.03,0.96,f'({let}) {tag}/Au(111)',transform=a.transAxes,fontsize=13,fontweight='bold',va='top')
    a.legend(loc='upper right')
ax[0].set_ylabel('PDOS (states/eV)')
top=max(a.get_ylim()[1] for a in ax)
for a in ax: a.set_ylim(0,top*1.38)
for e in ('png','pdf','tiff'): fig.savefig(f'Figure2_PDOS_origin.{e}',bbox_inches='tight')

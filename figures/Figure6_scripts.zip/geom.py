import re, sys, numpy as np, json
sys.path.insert(0,'/home/claude/dock/pca')
from scipy.spatial import cKDTree
from rdkit import Chem
from rdkit.Chem import rdDetermineBonds
from analiza import skel, core
U='/mnt/user-data/uploads/Au/SCF_Final/'
CFG={'VZPt':U+'FA_Au111_vertical_Z_pterin/FA_Au111_vertical_Z_pterin_scf.in','VXB':U+'FA_Au111_vertical_X_sideB/FA_Au111_vertical_X_sideB_scf.in'}
pose=Chem.SDMolSupplier('/home/claude/dock/pca/FA_pose1_caja18.sdf',removeHs=False)[0]; pS,pH=skel(pose)
Pfull=pose.GetConformer().GetPositions()
P=pH.GetConformer().GetPositions()[list(pS.GetSubstructMatch(core))]
PL=[l for l in open('/home/claude/dock/pca/proteina.pdb') if l.startswith(('ATOM','HETATM'))]
px0=np.array([[float(l[30:38]),float(l[38:46]),float(l[46:54])] for l in PL])
heavy=np.array([l[76:78].strip()!='H' for l in PL])
resid=[(l[17:20],int(l[22:26])) for l in PL]
def kabsch(P,Q):
    Pc,Qc=P.mean(0),Q.mean(0); H=(P-Pc).T@(Q-Qc); U_,S,Vt=np.linalg.svd(H)
    d=np.sign(np.linalg.det(Vt.T@U_.T)); R=Vt.T@np.diag([1,1,d])@U_.T; return R,Qc-R@Pc
def readqe(fn):
    L=open(fn).read().splitlines(); pos=[]
    for i,l in enumerate(L):
        s=l.strip().upper()
        if s.startswith('CELL_PARAMETERS'): cell=np.array([[float(x) for x in L[i+k].split()[:3]] for k in (1,2,3)])
        if s.startswith('ATOMIC_POSITIONS'):
            j=i+1
            while j<len(L) and re.match(r'^\s*[A-Za-z]{1,2}\s+-?\d',L[j]): t=L[j].split(); pos.append((t[0],*map(float,t[1:4]))); j+=1
    el=np.array([p[0] for p in pos]); X=np.array([p[1:] for p in pos]); return el,X,cell
def wpdb(fn,X,el=None,lines=None,bf=None,resn='LIG',chain='L'):
    with open(fn,'w') as f:
        for k,x in enumerate(X):
            b=0 if bf is None else bf[k]
            if lines is not None: l=lines[k]; f.write(l[:30]+'%8.3f%8.3f%8.3f'%tuple(x)+l[54:60]+'%6.2f'%b+l[66:].rstrip('\n')+'\n')
            else: f.write('HETATM%5d %-4s %3s %s%4d    %8.3f%8.3f%8.3f  1.00%6.2f          %2s\n'%(k+1,el[k],resn,chain,1,*x,b,el[k]))
        f.write('END\n')
out={}
for lab,fn in CFG.items():
    el,X,cell=readqe(fn); au=X[el=='Au']; mol=X[el!='Au']; me=el[el!='Au']
    qe=Chem.MolFromXYZBlock('%d\nx\n'%len(mol)+'\n'.join('%s %.6f %.6f %.6f'%(e,*p) for e,p in zip(me,mol)))
    rdDetermineBonds.DetermineConnectivity(qe); qS,qH=skel(qe)
    idx=[a.GetIdx() for a in qe.GetAtoms() if a.GetSymbol()!='H']
    Q=qH.GetConformer().GetPositions()[list(qS.GetSubstructMatch(core))]
    R,t=kabsch(P,Q); rmsd=np.sqrt(((P@R.T+t-Q)**2).sum(1).mean())
    ztop=au[:,2].max(); ztm=au[:,2][au[:,2]>ztop-1.0].mean()
    pxyz=px0@R.T+t
    big=np.vstack([au+i*cell[0]+j*cell[1] for i in range(-3,4) for j in range(-3,4)])
    dd,_=cKDTree(big).query(pxyz)
    hv=heavy
    below=(pxyz[hv,2]<ztop).sum(); clash=(dd[hv]<2.5).sum(); h=Q.mean(0)[2]-ztm
    # lift: minimal dz so that every heavy atom is >=3.0 A from any Au atom (and above plane)
    lo,hi=0,60
    for _ in range(40):
        m=(lo+hi)/2; d2,_=cKDTree(big).query(pxyz[hv]+[0,0,m])
        if d2.min()>=3.0 and (pxyz[hv,2]+m>ztop).all(): hi=m
        else: lo=m
    lift=ztop+3.0-pxyz[hv,2].min()
    lo2,hi2=0,60
    for _ in range(40):
        m=(lo2+hi2)/2
        if (pxyz[hv,2]+m-ztm).min()>=3.0: hi2=m
        else: lo2=m
    clres=sorted({resid[k] for k in np.where(dd<2.5)[0]},key=lambda r:r[1])
    out[lab]=dict(h=round(h,2),rmsd=round(rmsd,3),below=int(below),clash=int(clash),dmin=round(float(dd[hv].min()),2),lift_au=round(lift,2),lift_plane=round(hi2,2),n_clash_res=len(clres))
    print(lab,out[lab])
    
    # residue-level clash flag
    cset=set(clres); bf=[1.0 if resid[k] in cset else 0.0 for k in range(len(PL))]
    np.save(f'{lab}_frame.npy',dict(ztop=ztop,ztm=ztm,cell=cell,center=Q.mean(0),lift=lift),allow_pickle=True)
    wpdb(f'{lab}_prot.pdb',pxyz,lines=PL,bf=bf)
    wpdb(f'{lab}_prot_lift.pdb',pxyz+[0,0,lift],lines=PL)
    wpdb(f'{lab}_fa.pdb',mol,el=me)
    wpdb(f'{lab}_fa_lift.pdb',mol+[0,0,lift],el=me)
    c=Q.mean(0); sel=np.vstack([a for a in big if abs(a[0]-c[0])<36 and abs(a[1]-c[1])<36])
    wpdb(f'{lab}_au.pdb',sel,el=['Au']*len(sel),resn='AU',chain='S')
json.dump(out,open('geom.json','w'),indent=1)

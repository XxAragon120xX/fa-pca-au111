from pymol import cmd
import numpy as np, json, math
exec(open('/home/claude/fig3d/render.py').read().split('# ---------------- panel a')[0])
E=json.load(open('ext.json'))
S=25.0  # px per Å
X0,X1=-30.0,28.0
FOV=20.0
def setview(y0,y1,zc,w,h):
    Hang=(y1-y0); dist=Hang/(2*math.tan(math.radians(FOV/2)))
    xc=(X0+X1)/2; yc=(y0+y1)/2
    cmd.set('field_of_view',FOV); cmd.set('orthoscopic',1)
    cmd.set_view((1,0,0, 0,1,0, 0,0,1, 0,0,-dist, xc,yc,zc, dist-120, dist+120, 1))
def scene(lab,lift=False):
    base(); cmd.set('cartoon_transparency',0.0)
    cmd.load(f'v_{lab}_au.pdb','au'); zc=E[lab]['zc']
    cmd.remove(f'au and z > {zc-14}')
    cmd.show_as('spheres','au'); cmd.color('aucol','au')
    cmd.alter('au','vdw=1.44'); cmd.rebuild(); cmd.set('sphere_scale',0.95,'au')
    m=cmd.get_model('au'); ys=[a.coord[1] for a in m.atom]; xs=[a.coord[0] for a in m.atom]
    yt=max(ys)+1.3; yb=min(ys)-1.3; xa=X0-2; xb=X1+2; za=zc-14; zb=zc+30
    from pymol.cgo import BEGIN,END,TRIANGLES,COLOR,ALPHA,VERTEX,NORMAL
    v=lambda x,y,z:[VERTEX,x,y,z]
    def quad(p,n):
        out=[NORMAL,*n]
        for i in (0,1,2,0,2,3): out+=v(*p[i])
        return out
    P=[(xa,yb,za),(xb,yb,za),(xb,yt,za),(xa,yt,za),(xa,yb,zb),(xb,yb,zb),(xb,yt,zb),(xa,yt,zb)]
    F=[((4,5,6,7),(0,0,1)),((3,2,6,7),(0,1,0)),((0,1,5,4),(0,-1,0))]
    obj=[ALPHA,0.30,COLOR,0.95,0.70,0.20,BEGIN,TRIANGLES]
    for idx,n in F: obj+=quad([P[i] for i in idx],n)
    obj+=[END]; cmd.load_cgo(obj,'slabbox')
    sfx='_lift' if lift else ''
    cmd.load(f'v_{lab}_prot{sfx}.pdb','fra'); cmd.hide('everything','fra'); cmd.show('cartoon','fra')
    cmd.set('cartoon_oval_length',1.1); cmd.set('cartoon_loop_radius',0.25)
    cmd.color('prot','fra')
    if not lift: cmd.color('clash','fra and b > 0.5')
    cmd.load(f'v_{lab}_fa{sfx}.pdb','fa'); mol_style('fa'); cmd.color('forest','fa and elem C')
    cmd.set('sphere_scale',0.22,'fa'); cmd.set('sphere_scale',0.14,'fa and elem H')

Y0=-23.0
for lab,tag,y1,lift in (('VZPt','a',29.0,False),('VXB','b',29.0,False),('VZPt','c',53.0,True)):
    scene(lab,lift)
    w=int((X1-X0)*S); h=int((y1-Y0)*S)
    setview(Y0,y1,E[lab]['zc'],w,h)
    cmd.png(f'panel_{tag}.png',width=w,height=h,dpi=300,ray=1); print(tag,'ok',w,h)

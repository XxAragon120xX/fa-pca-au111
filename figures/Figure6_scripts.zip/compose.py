import numpy as np, json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from PIL import Image
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif'],'mathtext.fontset':'stix','font.size':8.5,'pdf.fonttype':42})
INK2='#3a3a3a'; S=25.0; X0=-30.0; Y0=-23.0
E=json.load(open('ext.json')); G=json.load(open('geom.json'))
def img(fn):
    a=np.array(Image.open(fn).convert('RGB')); a[(a>238).all(-1)]=255; return a
A,B,C=img('panel_a.png'),img('panel_b.png'),img('panel_c.png')
fig=plt.figure(figsize=(7.2,6.9))
# axes in figure fraction, same scale for all panels (px -> inches)
sc=3.45/A.shape[1]   # panel width 3.45 in
def put(im,x,y):
    w=im.shape[1]*sc; h=im.shape[0]*sc
    ax=fig.add_axes([x/7.2,y/6.9,w/7.2,h/6.9]); ax.imshow(im); ax.axis('off'); return ax
ha=A.shape[0]*sc; hc=C.shape[0]*sc
axb=put(B,0.05,0.15); axa=put(A,0.05,0.15+ha+0.32); axc=put(C,3.70,0.15+(2*ha+0.32-hc)/2)
def lab(ax,t,title):
    ax.text(0.0,1.0,t,transform=ax.transAxes,fontsize=12,fontweight='bold',va='bottom',ha='left')
    ax.text(0.07,1.0,title,transform=ax.transAxes,fontsize=8.5,va='bottom',ha='left')
g=G['VZPt']; lab(axa,'a',f'V-Z-Pt (most stable; pterin {g["h"]:.2f} Å above Au)')
axa.text(0.99,0.03,f'{g["below"]} atoms below the Au plane\n{g["clash"]} atoms < 2.5 Å from Au',transform=axa.transAxes,ha='right',va='bottom',fontsize=7.5,color='#b3141e',bbox=dict(fc='white',ec='none',alpha=0.8,pad=1.5))
g=G['VXB']; lab(axb,'b',f'V-X-B (least obstructed; pterin {g["h"]:.2f} Å above Au)')
axb.text(0.99,0.03,f'{g["below"]} atoms below the Au plane\n{g["clash"]} atoms < 2.5 Å from Au',transform=axb.transAxes,ha='right',va='bottom',fontsize=7.5,color='#b3141e',bbox=dict(fc='white',ec='none',alpha=0.8,pad=1.5))
lift=E['VZPt']['lift']; hp=E['VZPt']['pter']+lift
lab(axc,'c',f'(a) lifted by {lift:.1f} Å (receptor ≥ 3.0 Å from Au)')
y1c=53.0; px=lambda x:(x-X0)*S; py=lambda y:(y1c-y)*S
xa=px(-27.0)
axc.annotate('',xy=(xa,py(0.0)),xytext=(xa,py(hp)),arrowprops=dict(arrowstyle='<->',color='black',lw=0.9))
axc.plot([xa-12,px(0.0)],[py(hp)]*2,ls=(0,(3,2)),color='black',lw=0.7)
axc.text(xa+18,py(hp/2),f'pterin\n≈{hp:.0f} Å',fontsize=7.5,va='center',ha='left',bbox=dict(fc='white',ec='none',alpha=0.85,pad=1.0))
fig.legend(handles=[Patch(color='#9ec7eb',label='FRα (cartoon)'),Patch(color='#db2633',label='residues with atoms < 2.5 Å from Au'),
    Line2D([],[],color='#228b22',lw=2.2,label='adsorbed FA'),Patch(color='#efb53a',label='Au(111) slab')],
    loc='lower center',ncol=4,frameon=False,fontsize=7.5,bbox_to_anchor=(0.5,0.0),handlelength=1.4,columnspacing=1.2)
for ext,kw in (('png',{'dpi':600}),('pdf',{'dpi':600}),('tiff',{'dpi':600})):
    fig.savefig(f'Figure6_steric_FA.{ext}',**kw)
fig.savefig('prev6.png',dpi=130); print('ok')

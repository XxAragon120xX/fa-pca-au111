import numpy as np, json
def rd(fn):
    L=[l for l in open(fn) if l.startswith(('ATOM','HETATM'))]
    return L,np.array([[float(l[30:38]),float(l[38:46]),float(l[46:54])] for l in L])
def wr(fn,L,X):
    with open(fn,'w') as f:
        for l,r in zip(L,X): f.write(l[:30]+'%8.3f%8.3f%8.3f'%tuple(r)+l[54:])
        f.write('END\n')
ext={}
for lab in ('VZPt','VXB'):
    fr=np.load(f'{lab}_frame.npy',allow_pickle=True).item()
    Lp,Xp=rd(f'{lab}_prot.pdb'); c=fr['center']
    u,s,vt=np.linalg.svd((Xp-Xp.mean(0))[:,:2]); ax=np.r_[vt[0],0.0]
    ex=ax/np.linalg.norm(ax); ey=np.array([0,0,1.0]); ez=np.cross(ex,ey)
    Rv=np.vstack([ex,ey,ez]); o=np.array([c[0],c[1],fr['ztm']])
    tv=lambda X:(X-o)@Rv.T
    for nm in ('prot','prot_lift','fa','fa_lift'):
        L,X=rd(f'{lab}_{nm}.pdb'); wr(f'v_{lab}_{nm}.pdb',L,tv(X))
    La,A=rd(f'{lab}_au.pdb'); Av=tv(A); pv=tv(Xp)
    keep=(Av[:,0]>pv[:,0].min()-6)&(Av[:,0]<pv[:,0].max()+6)&(np.abs(Av[:,2]-pv[:,2].mean())<22)
    wr(f'v_{lab}_au.pdb',[La[0]]*keep.sum(),Av[keep])
    pl=tv(rd(f'{lab}_prot_lift.pdb')[1])
    ext[lab]=dict(xmin=float(pv[:,0].min()),xmax=float(pv[:,0].max()),ymax=float(pv[:,1].max()),ymax_lift=float(pl[:,1].max()),
                  zc=float(pv[:,2].mean()),pter=float(tv(c[None])[0][1]),lift=float(fr['lift']))
json.dump(ext,open('ext.json','w'),indent=1); print(json.dumps(ext,indent=1))

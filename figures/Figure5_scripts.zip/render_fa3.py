from pymol import cmd
import numpy as np, json, math
exec(open('render_fa.py').read().split("OFF={")[0])
cmd.set('stick_transparency',0.3,'prot'); cmd.label('all','""')
cmd.select('pt','fa and not elem H and (elem N or elem O or elem C)')  # refined below
# pterin atoms of the crystal FA by graph (first 13 heavy atoms in file order = pteridine+O4+NH2?)
def screen(sel,W,H):
    v=cmd.get_view(); R=np.array(v[:9]).reshape(3,3); cam=np.array(v[9:12]); org=np.array(v[12:15])
    X=np.array(cmd.get_coords(sel)) if False else np.array([a.coord for a in cmd.get_model(sel).atom])
    C=(X-org)@R+cam
    h=2*abs(cam[2])*math.tan(math.radians(cmd.get('field_of_view')and float(cmd.get('field_of_view'))/2)); w=h*W/H
    px=(C[:,0]/w+0.5)*W; py=(0.5-C[:,1]/h)*H
    return np.c_[px,py]
cmd.load('ligando_cristal.pdb','fol'); cmd.hide('everything','fol')
PT='fol and name N1+C2+NA2+N3+C4+O4+C4A+N5+C6+C7+N8+C8A'
out={}
def shot(name,W,H,zoomsel,buf,turns):
    cmd.orient('xtal')
    for a,g in turns: cmd.turn(a,g)
    cmd.zoom(zoomsel,buf)
    cmd.png(f'{name}.png',width=W,height=H,dpi=300,ray=1)
    out[name]={str(r):screen(f'prot and resi {r} and name {LAB[r]}',W,H)[0].tolist() for r in RES}
    out[name]['pt']=screen(PT,W,H).mean(0).tolist()
shot('fa_a',2000,1450,'xtal or (prot and resi '+'+'.join(map(str,RES))+' and not name N+C+O+CA)',2.5,[('x',-30),('y',10)])
shot('fa_b',1450,1450,PT,4.5,[('x',60),('y',-25)])
json.dump(out,open('labpos.json','w'),indent=1); print('ok')

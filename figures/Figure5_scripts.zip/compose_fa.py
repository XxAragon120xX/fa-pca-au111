import numpy as np, json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif'],'mathtext.fontset':'stix','font.size':9,'pdf.fonttype':42})
L=json.load(open('labpos.json'))
NAME={'81':'Asp81','85':'Tyr85','103':'Arg103','106':'Arg106','135':'His135','171':'Trp171','174':'Ser174','175':'Tyr175'}
def load(f):
    a=np.array(Image.open(f).convert('RGB')); a[(a>238).all(-1)]=255; return a
OFF={'fa_a':{'81':(-150,-60),'85':(280,-340),'103':(200,-40),'106':(80,170),'135':(230,90),'171':(-60,-190),'174':(-200,120),'175':(-210,40)},
     'fa_b':{'81':(20,-230),'85':(-300,60),'103':(60,170),'106':(220,0),'135':(170,-130),'171':(0,-180),'174':(-150,190),'175':(-30,170)}}
fig=plt.figure(figsize=(7.2,3.25))
axa=fig.add_axes([0.005,0.11,0.575,0.82]); axb=fig.add_axes([0.59,0.11,0.405,0.82])
for ax,nm,title in ((axa,'fa_a','(a) FA in the binding pocket'),(axb,'fa_b','(b) pterin, edge-on view (close-up)')):
    im=load(f'{nm}.png'); ax.imshow(im); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_color('#c9c8c2'); s.set_linewidth(0.6)
    ax.set_title(title,loc='left',fontsize=9.5)
    for r,(x,y) in L[nm].items():
        if r=='pt': continue
        dx,dy=OFF[nm][r]; tx,ty=min(max(x+dx,60),im.shape[1]-60),min(max(y+dy,40),im.shape[0]-40)
        ax.annotate(NAME[r],xy=(x,y),xytext=(tx,ty),fontsize=8,ha='center',va='center',
                    arrowprops=dict(arrowstyle='-',color='#555555',lw=0.5,shrinkA=3,shrinkB=2),
                    bbox=dict(boxstyle='round,pad=0.15',fc='white',ec='none',alpha=0.85))
    ax.set_xlim(0,im.shape[1]); ax.set_ylim(im.shape[0],0)
fig.legend(handles=[Line2D([],[],color='#eb6834',lw=3,label='FA, redocked (top-ranked pose, 18 Å box)'),
                    Line2D([],[],color='#4cb8d6',lw=2,label='FA, crystal (PDB 4LRH)')],
           loc='lower center',ncol=2,frameon=False,fontsize=8.5,bbox_to_anchor=(0.5,-0.01))
for e in ('png','pdf'): fig.savefig(f'Figure5_redocking.{e}',dpi=600)
fig.savefig('prev5.png',dpi=140); print('ok')

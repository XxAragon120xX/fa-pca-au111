from pymol import cmd
RES={81:'Asp81',85:'Tyr85',103:'Arg103',106:'Arg106',135:'His135',171:'Trp171',174:'Ser174',175:'Tyr175'}
LAB={81:'CG',85:'OH',103:'CZ',106:'CZ',135:'CE1',171:'CZ2',174:'OG',175:'OH'}
cmd.reinitialize(); cmd.bg_color('white')
for a,v in [('ray_trace_mode',1),('ray_trace_gain',0.04),('ray_trace_color','grey30'),('antialias',2),('ray_shadows',0),
            ('ambient',0.55),('specular',0.15),('orthoscopic',1),('depth_cue',0),('cartoon_transparency',0.72),
            ('stick_radius',0.15),('label_size',22),('label_color','black'),('label_font_id',9),('float_labels',1),
            ('label_outline_color','white'),('cartoon_color','grey80'),('two_sided_lighting',1)]: cmd.set(a,v)
cmd.set_color('fac',[0.92,0.41,0.20]); cmd.set_color('xtal',[0.30,0.72,0.84]); cmd.set_color('resc',[0.62,0.62,0.58])
cmd.load('proteina.pdb','prot'); cmd.load('FA_cristal.pdb','xtal'); cmd.load('FA_pose1.pdb','fa')
cmd.hide('everything'); cmd.show('cartoon','prot')
sel='prot and resi '+'+'.join(map(str,RES))+' and not name N+C+O'
cmd.show('sticks',sel); cmd.color('resc',f'{sel} and elem C'); cmd.color('blue',f'{sel} and elem N'); cmd.color('red',f'{sel} and elem O')
cmd.show('sticks','xtal and not elem H'); cmd.color('xtal','xtal'); cmd.set('stick_transparency',0.25,'xtal'); cmd.set('stick_radius',0.11,'xtal')
cmd.show('sticks','fa and not (elem H and neighbor elem C)'); cmd.set('stick_radius',0.21,'fa')
cmd.color('fac','fa and elem C'); cmd.color('blue','fa and elem N'); cmd.color('red','fa and elem O'); cmd.color('white','fa and elem H')
OFF={81:(-1.8,0.6,2),85:(1.5,1.2,2),103:(2.4,-0.4,2),106:(-2.2,-0.8,2),135:(2.4,-2.0,2),171:(-1.5,1.6,2),174:(-2.2,0.2,2),175:(1.8,0.8,2)}
for r,n in RES.items():
    s=f'prot and resi {r} and name {LAB[r]}'; cmd.label(s,f'"{n}"'); cmd.set('label_position',OFF[r],s)
cmd.orient('xtal'); cmd.turn('x',-30); cmd.turn('y',10)
cmd.zoom('xtal or (prot and resi '+'+'.join(map(str,RES))+' and not name N+C+O+CA)',2.5)
cmd.png('fa_redock.png',width=2200,height=1600,dpi=300,ray=1); print('ok')
